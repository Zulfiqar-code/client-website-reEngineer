<?php

require 'vendor/autoload.php';

echo "Stripe setup working!";
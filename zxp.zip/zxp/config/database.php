<?php
// config/database.php
session_start();

// ✅ CHANGE THESE ACCORDING TO YOUR SETUP
$host     = 'localhost';
$dbname   = 'zxp';
$username = 'root';
$password = '';  // XAMPP mein password empty hota hai

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// ── Helper functions ──────────────────────────────────────────

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

function isSuperAdmin() {
    return isset($_SESSION['is_super_admin']) && $_SESSION['is_super_admin'] == 1;
}

function isVIP() {
    return isset($_SESSION['is_vip']) && $_SESSION['is_vip'] == 1;
}

function getUser($pdo, $user_id = null) {
    $id = $user_id ?? $_SESSION['user_id'] ?? 0;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function addShout($pdo, $user_id, $message) {
    $stmt = $pdo->prepare("INSERT INTO shouts (user_id, message, created_at) VALUES (?, ?, NOW())");
    return $stmt->execute([$user_id, htmlspecialchars($message, ENT_QUOTES, 'UTF-8')]);
}

function getShouts($pdo, $limit = 10) {
    $limit = (int)$limit;
    $stmt = $pdo->prepare(
        "SELECT s.id, s.message, s.created_at, u.username, u.is_admin, 
                COALESCE(u.is_super_admin, 0) as is_super_admin, 
                COALESCE(u.is_vip, 0) as is_vip
         FROM shouts s
         JOIN users u ON u.id = s.user_id
         ORDER BY s.created_at DESC
         LIMIT :limit"
    );
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getTopPlayers($pdo, $limit = 5) {
    $limit = (int)$limit;
    try {
        $stmt = $pdo->prepare("SELECT * FROM gunxp_players ORDER BY xp DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        // Agar table nahi hai to sample data return karo
        return [
            ['nickname' => 'DonPetro', 'xp' => 1500000, 'level' => 50],
            ['nickname' => 'karakurt28', 'xp' => 1400000, 'level' => 48],
            ['nickname' => 'Pasa', 'xp' => 1300000, 'level' => 45],
            ['nickname' => '[Bold] ~ TheWind.', 'xp' => 1200000, 'level' => 43],
            ['nickname' => 'GaMeR YT', 'xp' => 1100000, 'level' => 40]
        ];
    }
}

function getSetting($pdo, $key) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : null;
    } catch (PDOException $e) {
        return null;
    }
}

function updateSetting($pdo, $key, $value) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = ?"
        );
        return $stmt->execute([$key, $value, $value]);
    } catch (PDOException $e) {
        return false;
    }
}

function getUsersList($pdo, $exclude_id = 0) {
    try {
        $stmt = $pdo->prepare("SELECT id, username, is_admin, COALESCE(is_super_admin,0) as is_super_admin, COALESCE(is_vip,0) as is_vip 
                               FROM users WHERE id != ? AND COALESCE(is_banned,0) = 0 ORDER BY username ASC");
        $stmt->execute([$exclude_id]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        $stmt = $pdo->prepare("SELECT id, username, is_admin, 0 as is_super_admin, 0 as is_vip FROM users WHERE id != ? ORDER BY username ASC");
        $stmt->execute([$exclude_id]);
        return $stmt->fetchAll();
    }
}

function getPrivateMessages($pdo, $user1, $user2, $limit = 50) {
    try {
        $stmt = $pdo->prepare(
            "SELECT pm.*, u.username as sender_name FROM private_messages pm
             JOIN users u ON u.id = pm.sender_id
             WHERE (pm.sender_id = ? AND pm.receiver_id = ?)
                OR (pm.sender_id = ? AND pm.receiver_id = ?)
             ORDER BY pm.created_at ASC"
        );
        $stmt->bindValue(1, $user1, PDO::PARAM_INT);
        $stmt->bindValue(2, $user2, PDO::PARAM_INT);
        $stmt->bindValue(3, $user2, PDO::PARAM_INT);
        $stmt->bindValue(4, $user1, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function getUnreadCount($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM private_messages WHERE receiver_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

// ── Forum Functions ───────────────────────────────────────────

function getForumCategories($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM forum_categories ORDER BY sort_order ASC");
        $cats = $stmt->fetchAll();
        foreach ($cats as &$cat) {
            // Total post count across all threads in this category
            $s = $pdo->prepare(
                "SELECT COUNT(*) FROM forum_posts fp
                 JOIN forum_threads ft ON ft.id = fp.thread_id
                 WHERE ft.category_id = ?"
            );
            $s->execute([$cat['id']]);
            $cat['post_count'] = (int)$s->fetchColumn();

            // Last post info
            $s2 = $pdo->prepare(
                "SELECT fp.created_at, u.username, ft.title as thread_title, ft.id as thread_id
                 FROM forum_posts fp
                 JOIN forum_threads ft ON ft.id = fp.thread_id
                 JOIN users u ON u.id = fp.user_id
                 WHERE ft.category_id = ?
                 ORDER BY fp.created_at DESC LIMIT 1"
            );
            $s2->execute([$cat['id']]);
            $cat['last_post'] = $s2->fetch() ?: null;
        }
        return $cats;
    } catch (PDOException $e) {
        return [];
    }
}

function getThreadsByCategory($pdo, $category_id, $limit = 20, $offset = 0) {
    try {
        $stmt = $pdo->prepare(
            "SELECT t.*, u.username,
                    (SELECT COUNT(*) FROM forum_posts WHERE thread_id = t.id) as post_count,
                    (SELECT fp2.created_at FROM forum_posts fp2 WHERE fp2.thread_id = t.id ORDER BY fp2.created_at DESC LIMIT 1) as last_post_at,
                    (SELECT u2.username FROM forum_posts fp2 JOIN users u2 ON u2.id = fp2.user_id WHERE fp2.thread_id = t.id ORDER BY fp2.created_at DESC LIMIT 1) as last_post_user
             FROM forum_threads t
             JOIN users u ON u.id = t.user_id
             WHERE t.category_id = ?
             ORDER BY t.is_pinned DESC, t.updated_at DESC
             LIMIT :lim OFFSET :off"
        );
        $stmt->bindValue(1, $category_id, PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function getThreadPosts($pdo, $thread_id, $limit = 20, $offset = 0) {
    try {
        $stmt = $pdo->prepare(
            "SELECT p.*, u.username, COALESCE(u.is_admin,0) as is_admin,
                    COALESCE(u.is_super_admin,0) as is_super_admin,
                    COALESCE(u.is_vip,0) as is_vip,
                    (SELECT COUNT(*) FROM forum_posts WHERE user_id = p.user_id) as user_post_count,
                    (SELECT COUNT(*) FROM forum_likes WHERE post_id = p.id) as like_count,
                    (SELECT COUNT(*) FROM forum_likes WHERE post_id = p.id AND user_id = ?) as user_liked
             FROM forum_posts p
             JOIN users u ON u.id = p.user_id
             WHERE p.thread_id = ?
             ORDER BY p.created_at ASC
             LIMIT :lim OFFSET :off"
        );
        $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
        $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
        $stmt->bindValue(2, $thread_id, PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function createThread($pdo, $category_id, $user_id, $title, $content) {
    try {
        // Generate unique slug from title
        $slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $title), '-'));
        $slug = substr($slug, 0, 180);
        // Make unique
        $check = $pdo->prepare("SELECT COUNT(*) FROM forum_threads WHERE slug = ?");
        $check->execute([$slug]);
        if ((int)$check->fetchColumn() > 0) {
            $slug = $slug . '-' . time();
        }

        $stmt = $pdo->prepare(
            "INSERT INTO forum_threads (category_id, user_id, title, slug, content, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())"
        );
        if ($stmt->execute([$category_id, $user_id,
            htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
            $slug,
            htmlspecialchars($content, ENT_QUOTES, 'UTF-8')])) {
            $thread_id = $pdo->lastInsertId();
            // Auto-create first post
            $pdo->prepare(
                "INSERT INTO forum_posts (thread_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())"
            )->execute([$thread_id, $user_id, htmlspecialchars($content, ENT_QUOTES, 'UTF-8')]);
            return $thread_id;
        }
        return false;
    } catch (PDOException $e) {
        return false;
    }
}

function addPost($pdo, $thread_id, $user_id, $content) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO forum_posts (thread_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())"
        );
        if ($stmt->execute([$thread_id, $user_id, htmlspecialchars($content, ENT_QUOTES, 'UTF-8')])) {
            $pdo->prepare("UPDATE forum_threads SET updated_at = NOW() WHERE id = ?")->execute([$thread_id]);
            return true;
        }
        return false;
    } catch (PDOException $e) {
        return false;
    }
}

function likePost($pdo, $post_id, $user_id) {
    try {
        // Toggle like
        $check = $pdo->prepare("SELECT id FROM forum_likes WHERE post_id = ? AND user_id = ?");
        $check->execute([$post_id, $user_id]);
        if ($check->fetch()) {
            $pdo->prepare("DELETE FROM forum_likes WHERE post_id = ? AND user_id = ?")->execute([$post_id, $user_id]);
            $action = 'unliked';
        } else {
            $pdo->prepare("INSERT INTO forum_likes (post_id, user_id) VALUES (?, ?)")->execute([$post_id, $user_id]);
            $action = 'liked';
        }
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_likes WHERE post_id = ?");
        $count_stmt->execute([$post_id]);
        return ['action' => $action, 'count' => (int)$count_stmt->fetchColumn()];
    } catch (PDOException $e) {
        return ['action' => 'error', 'count' => 0];
    }
}

function submitStaffApplication($pdo, $user_id, $position, $experience, $reason, $hours_weekly) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO staff_applications (user_id, position, experience, reason, hours_weekly, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())"
        );
        return $stmt->execute([$user_id,
            htmlspecialchars($position, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($experience, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($reason, ENT_QUOTES, 'UTF-8'),
            $hours_weekly]);
    } catch (PDOException $e) {
        return false;
    }
}

function submitBanAppeal($pdo, $user_id, $ban_id, $reason, $evidence) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO ban_appeals (user_id, ban_id, reason, evidence, created_at) VALUES (?, ?, ?, ?, NOW())"
        );
        return $stmt->execute([$user_id, $ban_id ?: null,
            htmlspecialchars($reason, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($evidence, ENT_QUOTES, 'UTF-8')]);
    } catch (PDOException $e) {
        return false;
    }
}

function submitPlayerReport($pdo, $reporter_id, $reported_player, $reason, $evidence) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO player_reports (reporter_id, reported_player, reason, evidence, created_at) VALUES (?, ?, ?, ?, NOW())"
        );
        return $stmt->execute([$reporter_id,
            htmlspecialchars($reported_player, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($reason, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($evidence, ENT_QUOTES, 'UTF-8')]);
    } catch (PDOException $e) {
        return false;
    }
}

function getServerStatus($pdo, $type = 'gunxp') {
    // Returns cached/static status; integrate real query-master lib for live data
    return ['online' => true, 'players' => rand(0, 32), 'max_players' => 32, 'map' => 'de_dust2'];
}
?>
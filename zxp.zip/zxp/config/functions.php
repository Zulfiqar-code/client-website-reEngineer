<?php
// config/functions.php

function formatNumber($num) {
    return number_format($num);
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    if ($diff < 60)     return $diff . 's ago';
    if ($diff < 3600)   return floor($diff/60) . 'm ago';
    if ($diff < 86400)  return floor($diff/3600) . 'h ago';
    if ($diff < 604800) return floor($diff/86400) . 'd ago';
    return date('d/m/Y', $timestamp);
}

function getKD($kills, $deaths) {
    if ($deaths == 0) return number_format($kills, 2);
    return number_format($kills / $deaths, 2);
}

function getRankIcon($rank) {
    if ($rank == 1) return '<span style="color:#FFD700;font-weight:900">#1 🥇</span>';
    if ($rank == 2) return '<span style="color:#C0C0C0;font-weight:900">#2 🥈</span>';
    if ($rank == 3) return '<span style="color:#CD7F32;font-weight:900">#3 🥉</span>';
    return '<span style="color:#888">#' . $rank . '</span>';
}

function formatDuration($minutes) {
    if ($minutes == 0) return '<span style="color:#ff4444;font-weight:bold">PERMANENT</span>';
    if ($minutes < 60)   return $minutes . ' min';
    if ($minutes < 1440) return round($minutes/60) . ' hours';
    return round($minutes/1440) . ' days';
}

function sanitize($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

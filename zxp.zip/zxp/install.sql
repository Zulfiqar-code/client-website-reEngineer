-- =============================================
--  ZXP.lt GAMING WEBSITE — Complete SQL v2.0
--  PhpMyAdmin mein RUN karo
-- =============================================

CREATE DATABASE IF NOT EXISTS zxp;
USE zxp;

-- Users table (updated with super_admin + google_id)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) DEFAULT '',
    google_id VARCHAR(100) DEFAULT NULL,
    level INT DEFAULT 1,
    xp INT DEFAULT 0,
    kills INT DEFAULT 0,
    deaths INT DEFAULT 0,
    headshots INT DEFAULT 0,
    playtime INT DEFAULT 0,
    is_admin TINYINT DEFAULT 0,
    is_super_admin TINYINT DEFAULT 0,
    is_vip TINYINT DEFAULT 0,
    is_banned TINYINT DEFAULT 0,
    ban_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Shouts table
CREATE TABLE IF NOT EXISTS shouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Private messages (user to user chat)
CREATE TABLE IF NOT EXISTS private_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bans table
CREATE TABLE IF NOT EXISTS bans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(64) NOT NULL,
    steam_id VARCHAR(50) NOT NULL,
    banned_by VARCHAR(50) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    ban_date DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Warnings table
CREATE TABLE IF NOT EXISTS warnings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(64) NOT NULL,
    level INT DEFAULT 1,
    xp INT DEFAULT 0,
    warned_by VARCHAR(50) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    warning_date DATE DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- GunXP players table
CREATE TABLE IF NOT EXISTS gunxp_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rank_num INT DEFAULT 0,
    nickname VARCHAR(64) NOT NULL,
    level INT DEFAULT 1,
    xp INT DEFAULT 0,
    kills INT DEFAULT 0,
    deaths INT DEFAULT 0,
    headshots INT DEFAULT 0,
    kd_ratio DECIMAL(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ZP Stats table
CREATE TABLE IF NOT EXISTS zp_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rank_num INT DEFAULT 0,
    nickname VARCHAR(64) NOT NULL,
    zp_points INT DEFAULT 0,
    zombie_kills INT DEFAULT 0,
    human_wins INT DEFAULT 0,
    nemesis_kills INT DEFAULT 0,
    survive_rounds INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Contact messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(64) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- News table
CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    author VARCHAR(50) DEFAULT 'Admin',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders table (Payment)
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL,
    package VARCHAR(50) NOT NULL,
    amount DECIMAL(8,2) NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    status ENUM('pending','paid','cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Achievements table
CREATE TABLE IF NOT EXISTS achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    achievement_name VARCHAR(100) NOT NULL,
    unlocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Google OAuth tokens (password recovery)
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    used TINYINT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── SAMPLE USERS (password: admin123) ────────────────────────
INSERT INTO users (username, password, email, level, xp, kills, deaths, is_admin, is_super_admin, is_vip) VALUES 
('Admin',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@zxp.lt',  50, 1245890, 48234, 12100, 1, 1, 1),
('Griffin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'griffin@zxp.lt', 41,  988320, 40220, 14200, 1, 0, 1);

-- ── SETTINGS ─────────────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value) VALUES 
('site_name',           'ZXP.lt Gaming'),
('site_url',            'https://zxp.lt'),
('gunxp_ip',            '135.125.147.173:27017'),
('zp_ip',               '135.125.147.173:27017'),
('double_xp_event',     '1'),
('crypto_wallet_btc',   'YOUR_BTC_WALLET_HERE'),
('crypto_wallet_eth',   'YOUR_ETH_WALLET_HERE'),
('crypto_wallet_usdt',  'YOUR_USDT_TRC20_WALLET_HERE'),
('paypal_email',        'your@paypal.com'),
('stripe_secret_key',   'sk_live_YOUR_KEY_HERE'),
('stripe_public_key',   'pk_live_YOUR_KEY_HERE'),
('admin_email',         'admin@zxp.lt'),
('discord_link',        'https://discord.gg/BSp88gJmpx'),
('maintenance_mode',    '0'),
('google_client_id',    'YOUR_GOOGLE_CLIENT_ID_HERE'),
('google_client_secret','YOUR_GOOGLE_CLIENT_SECRET_HERE');

-- ── SAMPLE GUNXP PLAYERS ─────────────────────────────────────
INSERT INTO gunxp_players (rank_num, nickname, level, xp, kills, deaths, headshots, kd_ratio) VALUES 
(1, '[Infected]~ ImplosioN^', 45, 1245890, 48234, 12100, 15234, 3.98),
(2, 'THE_V AMPIR',            43, 1102445, 44100, 13500, 12890, 3.27),
(3, 'Griffin',                41,  988320, 40220, 14200, 11234, 2.83),
(4, 'Vulture | ~ Crowley',    39,  875110, 36700, 15800,  9876, 2.32),
(5, "Don't Be Mad.",          38,  820500, 33400, 16200,  8765, 2.06);

-- ── SAMPLE ZP STATS ──────────────────────────────────────────
INSERT INTO zp_stats (rank_num, nickname, zp_points, zombie_kills, human_wins, nemesis_kills, survive_rounds) VALUES 
(1, '[Infected]~ ImplosioN^', 98500, 12450, 8900, 345, 2340),
(2, 'THE_V AMPIR',            87200, 10800, 8100, 290, 1980),
(3, 'Griffin',                75400,  9200, 7400, 210, 1650);

-- ── SAMPLE BANS ──────────────────────────────────────────────
INSERT INTO bans (nickname, steam_id, banned_by, reason, duration, ban_date) VALUES 
('hAX0r_pro',    'STEAM_0:1:12345', 'SuperAdmin', 'Wallhack / ESP', 'PERMANENT', '2024-06-05'),
('AimB0T_King',  'STEAM_0:0:67890', 'Admin_X',    'Aimbot',         'PERMANENT', '2024-06-04'),
('ToxicPlayer99','STEAM_0:1:11111', 'Mod_Y',       'Racism',         '7 Days',    '2024-06-03');

-- ── SAMPLE WARNINGS ──────────────────────────────────────────
INSERT INTO warnings (nickname, level, xp, warned_by, reason, warning_date) VALUES 
('B3auty',            34, 696058, 'Admin_X',    'Swearing',  '2024-06-01'),
('Dafnostefanomenos', 31, 459189, 'SuperAdmin', 'Team Kill', '2024-06-01');

-- Forum categories table
CREATE TABLE IF NOT EXISTS forum_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_admin_only TINYINT DEFAULT 0,
    is_locked TINYINT DEFAULT 0,
    sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Forum threads table
CREATE TABLE IF NOT EXISTS forum_threads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    views INT DEFAULT 0,
    is_pinned TINYINT DEFAULT 0,
    is_locked TINYINT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES forum_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Forum posts table
CREATE TABLE IF NOT EXISTS forum_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    thread_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Forum post likes table
CREATE TABLE IF NOT EXISTS forum_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (post_id, user_id),
    FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Staff applications table
CREATE TABLE IF NOT EXISTS staff_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    position VARCHAR(50) NOT NULL,
    experience TEXT NOT NULL,
    reason TEXT NOT NULL,
    hours_weekly INT NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ban appeals table
CREATE TABLE IF NOT EXISTS ban_appeals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ban_id INT DEFAULT NULL,
    reason TEXT NOT NULL,
    evidence TEXT,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Player reports table
CREATE TABLE IF NOT EXISTS player_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT NOT NULL,
    reported_player VARCHAR(64) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    evidence TEXT,
    status ENUM('pending','reviewed','resolved') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── SAMPLE FORUM CATEGORIES ──────────────────────────────────
INSERT INTO forum_categories (name, description, is_admin_only, is_locked, sort_order) VALUES
('Official News & Announcements', 'Server news, updates and events from staff', 1, 0, 1),
('General Discussion', 'Talk about anything related to the server', 0, 0, 2),
('Server Rules', 'Read the rules before playing', 0, 1, 3),
('Report a Player', 'Submit player reports here', 0, 0, 4),
('Ban Appeals', 'Appeal your ban here', 0, 0, 5),
('Staff Applications', 'Apply to become a staff member', 0, 0, 6);

-- ── SAMPLE NEWS ──────────────────────────────────────────────
INSERT INTO news (title, content, author, created_at) VALUES 
('Welcome to ZXP.lt Gaming!',   'Best CS 1.6 GunXP and Zombie Plague server. Join us for double XP weekend!', 'Admin', NOW()),
('Double XP Event This Weekend!','Play now and earn double XP! Top 3 players win free VIP for 1 month.',       'Admin', NOW()),
('Anti-Cheat Updated',           'Our anti-cheat system has been upgraded. Hackers get permanent ban.',         'Admin', NOW());

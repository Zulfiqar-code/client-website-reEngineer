<?php
// index.php — ZXP.lt Main Entry Point v2.0
require_once 'config/database.php';
require_once 'config/functions.php';

// Fetch all data
$topPlayers   = getTopPlayers($pdo, 5);
$shouts       = getShouts($pdo, 10);
$memberCount  = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$newestMember = $pdo->query("SELECT username FROM users ORDER BY created_at DESC LIMIT 1")->fetchColumn();
$warnings     = $pdo->query("SELECT * FROM warnings ORDER BY id DESC LIMIT 20")->fetchAll();
$bans         = $pdo->query("SELECT * FROM bans ORDER BY id DESC LIMIT 20")->fetchAll();
$gunxpPlayers = $pdo->query("SELECT * FROM gunxp_players ORDER BY xp DESC LIMIT 20")->fetchAll();
$zpStats      = $pdo->query("SELECT * FROM zp_stats ORDER BY zp_points DESC LIMIT 10")->fetchAll();
$news         = $pdo->query("SELECT * FROM news ORDER BY created_at DESC LIMIT 5")->fetchAll();
$onlineMembers = rand(1, 8);
$gunxpIp      = getSetting($pdo, 'gunxp_ip')        ?? '135.125.147.173:27017';
$zpIp         = getSetting($pdo, 'zp_ip')            ?? '135.125.147.173:27017';
$discordLink  = getSetting($pdo, 'discord_link')     ?? 'https://discord.gg/BSp88gJmpx';
$adminEmail   = getSetting($pdo, 'admin_email')      ?? 'admin@zxp.lt';
$doubleXp     = getSetting($pdo, 'double_xp_event') == '1';
$btcWallet    = getSetting($pdo, 'crypto_wallet_btc')  ?? 'YOUR_BTC_WALLET';
$ethWallet    = getSetting($pdo, 'crypto_wallet_eth')  ?? 'YOUR_ETH_WALLET';
$usdtWallet   = getSetting($pdo, 'crypto_wallet_usdt') ?? 'YOUR_USDT_TRC20_WALLET';
$unreadCount  = isLoggedIn() ? getUnreadCount($pdo, $_SESSION['user_id']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="description" content="ZXP.lt — Best Counter-Strike 1.6 GunXP and Zombie Plague Server">
<title>ZXP.lt — CS 1.6 GunXP &amp; Zombie Plague Server</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- ══ MODAL ══════════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal">
  <div class="modal">
    <div class="modal-title">
      <span id="modal-title">Notice</span>
      <span class="modal-close" onclick="closeModal()">✕</span>
    </div>
    <div class="modal-body">
      <p id="modal-msg"></p>
      <button class="modal-ok" onclick="closeModal()">OK</button>
    </div>
  </div>
</div>

<!-- ══ PAYMENT MODAL (Crypto + Discord) ═══════════════════════ -->
<div class="modal-overlay" id="payment-modal">
  <div class="modal" style="max-width:520px">
    <div class="modal-title">
      <span id="pay-modal-title">💎 Order VIP / Admin</span>
      <span class="modal-close" onclick="closePayModal()">✕</span>
    </div>
    <div class="modal-body">
      <div id="pay-step-1">
        <div class="form-row"><label>Your In-Game Nickname *</label><input type="text" id="pay_username" placeholder="Enter your exact nickname"></div>
        <div class="form-row"><label>Package *</label>
          <select id="pay_package">
            <option value="vip_1m">⭐ VIP — 1 Month (€5)</option>
            <option value="vip_3m">⭐ VIP — 3 Months (€12)</option>
            <option value="admin_1m">👑 Admin — 1 Month (€10)</option>
            <option value="admin_3m">👑 Admin — 3 Months (€25)</option>
          </select>
        </div>
        <div class="form-row"><label>Payment Method *</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px;">
            <label class="pay-method-label" id="lbl-crypto_btc">
              <input type="radio" name="pay_method" value="crypto_btc" onchange="selectMethod('crypto_btc')">
              <span>₿ Bitcoin (BTC)</span>
            </label>
            <label class="pay-method-label" id="lbl-crypto_eth">
              <input type="radio" name="pay_method" value="crypto_eth" onchange="selectMethod('crypto_eth')">
              <span>Ξ Ethereum (ETH)</span>
            </label>
            <label class="pay-method-label" id="lbl-crypto_usdt">
              <input type="radio" name="pay_method" value="crypto_usdt" onchange="selectMethod('crypto_usdt')">
              <span>💵 USDT (TRC20)</span>
            </label>
            <label class="pay-method-label" id="lbl-paypal">
              <input type="radio" name="pay_method" value="paypal" onchange="selectMethod('paypal')">
              <span>🅿 PayPal</span>
            </label>
            <label class="pay-method-label" id="lbl-stripe">
              <input type="radio" name="pay_method" value="stripe" onchange="selectMethod('stripe')">
              <span>💳 Card (Stripe)</span>
            </label>
            <label class="pay-method-label" id="lbl-discord">
              <input type="radio" name="pay_method" value="discord" onchange="selectMethod('discord')">
              <span>💬 Discord</span>
            </label>
          </div>
        </div>
        <button class="submit-btn" style="width:100%;margin-top:12px" onclick="submitOrder()">Continue →</button>
      </div>
      <div id="pay-step-2" style="display:none;text-align:center;">
        <div id="pay-instructions"></div>
        <button class="submit-btn" style="margin-top:14px" onclick="closePayModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- ══ CHAT MODAL (User to User) ══════════════════════════════ -->
<div class="modal-overlay" id="chat-modal">
  <div class="modal chat-modal-box">
    <div class="modal-title">
      <span>💬 Private Messages</span>
      <span class="modal-close" onclick="closeChatModal()">✕</span>
    </div>
    <div class="chat-layout">
      <div class="chat-users-panel" id="chat-users-panel">
        <div class="chat-search-box"><input type="text" id="chat-user-search" placeholder="🔍 Search user..." oninput="filterChatUsers()"></div>
        <div id="chat-users-list"><div style="color:#666;padding:10px;text-align:center">Loading...</div></div>
      </div>
      <div class="chat-messages-panel" id="chat-messages-panel">
        <div class="chat-no-select" id="chat-no-select">
          <div style="text-align:center;color:#555;padding:40px 20px;">
            <div style="font-size:40px;margin-bottom:10px">💬</div>
            <p>Select a user to start chatting</p>
          </div>
        </div>
        <div id="chat-active" style="display:none;height:100%;display:flex;flex-direction:column;">
          <div class="chat-header" id="chat-with-name">Chat</div>
          <div class="chat-messages" id="chat-messages-box"></div>
          <div class="chat-input-row">
            <input type="text" id="chat-input-msg" placeholder="Type message..." maxlength="500" onkeypress="if(event.key==='Enter')sendChatMsg()">
            <button onclick="sendChatMsg()">Send</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ══ PROFILE MODAL ═══════════════════════════════════════════ -->
<div class="modal-overlay" id="profile-modal">
  <div class="modal" style="max-width:420px">
    <div class="modal-title">
      <span>👤 Edit Profile</span>
      <span class="modal-close" onclick="closeProfileModal()">✕</span>
    </div>
    <div class="modal-body">
      <div id="profile-tabs" style="display:flex;gap:6px;margin-bottom:14px;">
        <button class="tab-btn active" id="tab-profile" onclick="switchProfileTab('profile')">Change Info</button>
        <button class="tab-btn" id="tab-recover" onclick="switchProfileTab('recover')">Recover Password</button>
      </div>
      <!-- Change Info Tab -->
      <div id="profile-tab-profile">
        <div class="form-row"><label>New Username (leave blank to keep)</label><input type="text" id="prof_new_username" placeholder="New username"></div>
        <div class="form-row"><label>New Password (leave blank to keep)</label><input type="password" id="prof_new_password" placeholder="New password (min 4)"></div>
        <div class="form-row"><label>Current Password * (required)</label><input type="password" id="prof_current_password" placeholder="Your current password"></div>
        <button class="submit-btn" style="width:100%;margin-top:10px" onclick="updateProfile()">Save Changes</button>
      </div>
      <!-- Recover Tab -->
      <div id="profile-tab-recover" style="display:none;">
        <p style="color:#aaa;font-size:12px;margin-bottom:12px;">Enter your registered email. We'll initiate recovery via Google account link or Discord.</p>
        <div class="form-row"><label>Registered Email *</label><input type="email" id="recover_email" placeholder="your@email.com"></div>
        <button class="submit-btn" style="width:100%;margin-top:10px" onclick="doGoogleRecover()">Recover via Email / Google</button>
        <div style="margin-top:12px;padding:10px;background:#0d0d0d;border:1px solid #333;border-radius:4px;font-size:12px;color:#888;">
          Or contact admin on Discord: <a href="<?= htmlspecialchars($discordLink) ?>" target="_blank" style="color:#5865F2"><?= htmlspecialchars($discordLink) ?></a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ══ AI CHATBOT ══════════════════════════════════════════════ -->
<div id="chatbot-bubble" onclick="toggleChatbot()" title="ZXP AI Assistant">
  🤖 <span class="chatbot-label">AI Help</span>
</div>
<div id="chatbot-box" style="display:none;">
  <div class="chatbot-header">
    <span>🤖 ZXP Assistant</span>
    <span style="cursor:pointer;font-size:16px" onclick="toggleChatbot()">✕</span>
  </div>
  <div class="chatbot-messages" id="chatbot-messages">
    <div class="chatbot-msg bot">👋 Hi! I'm ZXP Assistant. Ask me anything about the server, VIP, rules, or how to connect!</div>
  </div>
  <div class="chatbot-input-row">
    <input type="text" id="chatbot-input" placeholder="Ask something..." onkeypress="if(event.key==='Enter')sendBotMsg()" maxlength="200">
    <button onclick="sendBotMsg()">➤</button>
  </div>
</div>

<!-- ══ HEADER ══════════════════════════════════════════════════ -->
<div class="site-logo">
  <div class="logo-left">
    <h1>⚔ ZXP.LT GAMING</h1>
    <p>Counter-Strike 1.6 | GunXP | Zombie Plague | Best Server 2025</p>
  </div>
  <div class="server-ip">
    <span>connect <?= htmlspecialchars($gunxpIp) ?></span>
    <small>GunXP / ZP Server</small>
  </div>
</div>

<!-- ══ TOP NAV ════════════════════════════════════════════════ -->
<div class="topnav">
  <a onclick="showPage('home')">🏠 Home</a>
  <a onclick="showPage('forum')">💬 Forum</a>
  <a onclick="showPage('store')">🛒 Store</a>
  <a href="<?= htmlspecialchars($discordLink) ?>" target="_blank">💬 Discord</a>
  <a onclick="openPayModal()">💎 Donate / VIP</a>
  <a onclick="showPage('apply')">📝 Apply Staff</a>
  <a onclick="showPage('contact')">📞 Support</a>
  <a onclick="showPage('reports')">⚠ Report Player</a>
  <a onclick="showPage('ban-appeal')">📋 Ban Appeal</a>
  <?php if(isLoggedIn()): ?>
  <a onclick="openChatModal()" id="nav-chat-btn">✉ Messages <?php if($unreadCount > 0): ?><span class="badge-count"><?= $unreadCount ?></span><?php endif; ?></a>
  <a onclick="openProfileModal()">👤 Profile</a>
  <?php endif; ?>
</div>

<!-- ══ MAIN WRAP ═══════════════════════════════════════════════ -->
<div class="wrap">

<!-- ┌─ LEFT SIDEBAR ──────────────────────────────────────────── -->
<div class="sidebar">

  <div class="sidebar-section">
    <div class="sidebar-title">Navigation</div>
    <div class="sidebar-nav">
      <a class="red" onclick="openPayModal()">▶ (!) Order ADMIN / VIP</a>
      <a onclick="showPage('vip')">▶ VIP / ADMIN Info</a>
      <a onclick="showPage('warnings')" id="nav-warnings">▶ Last Warnings</a>
      <a onclick="showPage('rules')" id="nav-rules">▶ Server Rules <span style="background:#cc0000;color:#fff;padding:1px 5px;font-size:10px;border-radius:2px;margin-left:4px;">!</span></a>
      <a onclick="showPage('banlist')" id="nav-banlist">▶ Ban List</a>
      <a onclick="showPage('gunxp')" id="nav-gunxp">▶ GunXP Top Players</a>
      <a onclick="showPage('achievements')" id="nav-ach">▶ Achievements</a>
      <a onclick="showPage('zpstats')" id="nav-zp">▶ ZP Stats</a>
      <a onclick="showPage('contact')" id="nav-contact">▶ Contact Super Admins</a>
      <?php if(isLoggedIn()): ?>
      <a onclick="openChatModal()" id="nav-chat">▶ 💬 Private Chat <?php if($unreadCount>0): ?><span class="badge-count"><?= $unreadCount ?></span><?php endif; ?></a>
      <?php endif; ?>
    </div>
  </div>

  <div class="sidebar-section">
    <div class="sidebar-title">Top 5 Players</div>
    <div class="top5-list">
      <div class="top5-header"><span>#</span><strong>Nickname</strong></div>
      <?php foreach($topPlayers as $i => $p): $r = $i+1; ?>
      <div class="top5-item">
        <span class="top5-rank-<?= $r<=3?$r:'' ?>"><?= $r ?></span>
        <a onclick="showPage('gunxp')" title="<?= sanitize($p['nickname']) ?>">
          <?= mb_strimwidth(sanitize($p['nickname']), 0, 16, '…') ?>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="sidebar-section">
    <div class="sidebar-title">Users Online</div>
    <div class="online-info">
      <p>▶ Guests: <span class="online-count" id="guest-count"><?= rand(5,15) ?></span></p>
      <p id="members-online">▶ Members: <strong><?= $onlineMembers ?></strong></p>
      <p>▶ Registered: <strong><?= number_format($memberCount) ?></strong></p>
      <p>▶ Newest: <strong><?= sanitize($newestMember ?: 'N/A') ?></strong></p>
    </div>
  </div>

</div><!-- /sidebar -->

<!-- ┌─ MAIN CONTENT ──────────────────────────────────────────── -->
<div class="main">

  <!-- HOME PAGE -->
  <div class="page active" id="page-home">
    <div class="page-title">WELCOME TO ZXP.LT GAMING</div>
    <div class="welcome-box">
      <h2>Welcome to ZXP.lt!</h2>
      <p>The best Counter-Strike 1.6 server featuring GunXP and Zombie Plague mods. Join thousands of players and climb the ranks!</p>
      <?php if($doubleXp): ?>
      <div style="background:#1a1200;border:2px solid #cc9900;padding:12px;margin:10px 0;text-align:center;border-radius:4px;">
        🔥 <strong style="color:#ffcc00">DOUBLE XP EVENT ACTIVE!</strong> 🔥 — Play now and earn double experience!
      </div>
      <?php endif; ?>
      <div class="server-info-grid">
        <div class="server-card"><h3>🎮 GunXP Server</h3><p>IP: <?= sanitize($gunxpIp) ?><br>Map: de_dust2<br>Mode: GunXP Mod</p></div>
        <div class="server-card"><h3>🧟 Zombie Plague</h3><p>IP: <?= sanitize($zpIp) ?><br>Map: zm_frostwork<br>Mode: ZP 5.0</p></div>
        <div class="server-card"><h3>📊 Server Stats</h3><p>Members: <?= number_format($memberCount) ?><br>Games: 128,447<br>Uptime: 99.8%</p></div>
        <div class="server-card"><h3>💎 VIP / Admin</h3><p>VIP from €5/month<br>Admin from €10/month<br><a onclick="openPayModal()" style="color:#cc0000;cursor:pointer;font-weight:bold;">Order Now →</a></p></div>
      </div>
    </div><!-- /welcome-box -->
  </div><!-- /page-home -->

<!-- FORUM PAGE -->
<div class="page" id="page-forum">
    <div class="page-title">COMMUNITY FORUM</div>
    <div id="forum-categories"></div>
</div>

<!-- FORUM THREAD VIEW -->
<div class="page" id="page-forum-thread" style="display:none;">
    <div class="page-title" id="forum-thread-title"></div>
    <div id="forum-posts"></div>
    <div id="forum-reply-form" style="margin-top: 20px;">
        <textarea id="forum-reply-content" rows="5" placeholder="Write your reply..." style="width:100%;padding:10px;background:#0d0d0d;border:1px solid #333;color:#fff;border-radius:4px;"></textarea>
        <button onclick="submitForumReply()" class="submit-btn" style="margin-top:10px;">Post Reply</button>
    </div>
</div>

<!-- NEW THREAD FORM -->
<div class="page" id="page-new-thread">
    <div class="page-title">CREATE NEW THREAD</div>
    <div class="apply-form">
        <div class="form-row">
            <label>Category *</label>
            <select id="newthread_category" class="form-input"></select>
        </div>
        <div class="form-row">
            <label>Title *</label>
            <input type="text" id="newthread_title" class="form-input" placeholder="Thread title">
        </div>
        <div class="form-row">
            <label>Content *</label>
            <textarea id="newthread_content" rows="8" class="form-input" placeholder="Write your thread content here..."></textarea>
        </div>
        <button onclick="createNewThread()" class="submit-btn">Create Thread</button>
    </div>
</div>

<!-- STORE PAGE -->
<div class="page" id="page-store">
    <div class="page-title">🛒 STORE - BUY VIP / ADMIN</div>
    <div class="server-info-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;">
        <div class="store-product">
            <h3>⭐ VIP - 1 Month</h3>
            <div class="store-price">€5</div>
            <ul style="text-align:left;font-size:12px;color:#aaa;margin:10px 0;">
                <li>✓ Reserved slot</li>
                <li>✓ VIP tag</li>
                <li>✓ Double XP</li>
                <li>✓ VIP weapons</li>
            </ul>
            <button class="buy-btn" onclick="openPayModal('vip_1m')">Buy Now</button>
        </div>
        <div class="store-product">
            <h3>⭐ VIP - 3 Months</h3>
            <div class="store-price">€12</div>
            <ul style="text-align:left;font-size:12px;color:#aaa;margin:10px 0;">
                <li>✓ All VIP benefits</li>
                <li>✓ Save €3</li>
                <li>✓ Priority support</li>
            </ul>
            <button class="buy-btn" onclick="openPayModal('vip_3m')">Buy Now</button>
        </div>
        <div class="store-product">
            <h3>👑 Admin - 1 Month</h3>
            <div class="store-price">€10</div>
            <ul style="text-align:left;font-size:12px;color:#aaa;margin:10px 0;">
                <li>✓ All VIP perks</li>
                <li>✓ Admin tag</li>
                <li>✓ Kick/warn/mute</li>
                <li>✓ Change maps</li>
            </ul>
            <button class="buy-btn" onclick="openPayModal('admin_1m')">Buy Now</button>
        </div>
        <div class="store-product">
            <h3>👑 Admin - 3 Months</h3>
            <div class="store-price">€25</div>
            <ul style="text-align:left;font-size:12px;color:#aaa;margin:10px 0;">
                <li>✓ All Admin perks</li>
                <li>✓ Save €5</li>
                <li>✓ Full privileges</li>
            </ul>
            <button class="buy-btn" onclick="openPayModal('admin_3m')">Buy Now</button>
        </div>
    </div>
</div>

<!-- APPLY STAFF PAGE -->
<div class="page" id="page-apply">
    <div class="page-title">📝 APPLY FOR STAFF</div>
    <div class="apply-form">
        <div class="form-row">
            <label>Position *</label>
            <select id="apply_position" class="form-input">
                <option value="Admin">Admin</option>
                <option value="Moderator">Moderator</option>
                <option value="Support">Support Staff</option>
            </select>
        </div>
        <div class="form-row">
            <label>Previous Experience *</label>
            <textarea id="apply_experience" rows="4" class="form-input" placeholder="Describe your previous staff experience..."></textarea>
        </div>
        <div class="form-row">
            <label>Why do you want to join? *</label>
            <textarea id="apply_reason" rows="4" class="form-input" placeholder="Tell us why you'd be a good fit..."></textarea>
        </div>
        <div class="form-row">
            <label>Hours per week you can dedicate *</label>
            <input type="number" id="apply_hours" class="form-input" placeholder="e.g., 10">
        </div>
        <button onclick="submitStaffApplication()" class="submit-btn">Submit Application</button>
    </div>
</div>

<!-- REPORT PLAYER PAGE -->
<div class="page" id="page-reports">
    <div class="page-title">⚠ REPORT A PLAYER</div>
    <div class="report-form">
        <div class="form-row">
            <label>Player Name *</label>
            <input type="text" id="report_username" class="form-input" placeholder="Exact in-game nickname">
        </div>
        <div class="form-row">
            <label>What happened? * <span style="color:#666;font-size:10px">(describe in detail — include rule broken, time, server)</span></label>
            <textarea id="report_reason_text" class="report-free-text" rows="6" placeholder="Example: Player 'XYZ' was using aimbot on GunXP server around 3pm. Every shot was a headshot and movement was inhuman. He killed 20 players in a row without missing..."></textarea>
        </div>
        <div class="form-row">
            <label>Proof Link <span style="color:#666;font-size:10px">(screenshot, video — optional but helps a lot)</span></label>
            <input type="text" id="report_evidence" class="form-input" placeholder="https://imgur.com/... or https://streamable.com/...">
        </div>
        <button onclick="submitPlayerReport()" class="submit-btn">Submit Report</button>
    </div>
</div>

<!-- BAN APPEAL PAGE -->
<div class="page" id="page-ban-appeal">
    <div class="page-title">📋 BAN APPEAL</div>
    <div style="background:#0d0d0d;border:1px solid #444;padding:12px;margin-bottom:16px;border-radius:4px;font-size:13px;color:#aaa;">
        <strong style="color:#fff">📌 Before submitting:</strong> Make sure you have read the
        <a onclick="showPage('rules')" style="color:#cc0000;cursor:pointer">server rules</a>.
        False appeals will result in an extended ban. Appeals are reviewed within 48 hours.
    </div>
    <div class="apply-form">
        <div class="form-row">
            <label>Ban ID (if known)</label>
            <input type="number" id="appeal_ban_id" class="form-input" placeholder="Leave blank if unknown">
        </div>
        <div class="form-row">
            <label>Why should your ban be lifted? *</label>
            <textarea id="appeal_reason" rows="5" class="form-input" placeholder="Explain your situation honestly..."></textarea>
        </div>
        <div class="form-row">
            <label>Evidence / Proof (screenshot or video link)</label>
            <input type="text" id="appeal_evidence" class="form-input" placeholder="https://...">
        </div>
        <button onclick="submitBanAppeal()" class="submit-btn">Submit Appeal</button>
    </div>
</div>



<!-- NEWS PAGE -->
<div class="page" id="page-news">
  <div class="page-title">NEWS &amp; UPDATES</div>
    <?php foreach($news as $item): ?>
    <div class="news-item">
      <div class="news-date">📅 <?= date('d/m/Y', strtotime($item['created_at'])) ?> &nbsp;by <?= sanitize($item['author']) ?></div>
      <div class="news-title">🔥 <?= sanitize($item['title']) ?></div>
      <div class="news-text"><?= sanitize($item['content']) ?></div>
    </div>
    <?php endforeach; ?>
  <?php if(empty($news)): ?><p style="color:#666;padding:20px">No news yet.</p><?php endif; ?>
</div>

  <!-- WARNINGS PAGE -->
  <div class="page" id="page-warnings">
    <div class="page-title">LAST WARNINGS</div>
    <table class="data-table">
      <thead><tr><th>Nickname</th><th>Level</th><th>XP</th><th>Warned By</th><th>Reason</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($warnings)): ?>
        <tr><td colspan="6" style="text-align:center;color:#777">No warnings found</td></tr>
        <?php else: foreach($warnings as $w): ?>
        <tr>
          <td><?= sanitize($w['nickname']) ?></td>
          <td><?= (int)$w['level'] ?></td>
          <td><?= number_format((int)$w['xp']) ?></td>
          <td><?= sanitize($w['warned_by']) ?></td>
          <td><?= sanitize($w['reason']) ?></td>
          <td><?= $w['warning_date'] ? date('d/m/Y', strtotime($w['warning_date'])) : '—' ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- RULES PAGE -->
  <div class="page" id="page-rules">
    <div class="page-title">SERVER RULES</div>
    <div class="rules-section"><h3>🎮 General Rules</h3><div class="rules-list"><ul>
      <li><span class="rule-num">1.</span> No hacking, cheating, or exploiting game bugs. Permanent ban.</li>
      <li><span class="rule-num">2.</span> Respect all players and admins at all times.</li>
      <li><span class="rule-num">3.</span> No spamming in chat or voice chat.</li>
      <li><span class="rule-num">4.</span> No advertising other servers or websites.</li>
      <li><span class="rule-num">5.</span> No racist, sexist, or offensive language.</li>
    </ul></div></div>
    <div class="rules-section"><h3>⚔️ Gameplay Rules</h3><div class="rules-list"><ul>
      <li><span class="rule-num">1.</span> No intentional team killing (TK).</li>
      <li><span class="rule-num">2.</span> No camping in unfair positions.</li>
      <li><span class="rule-num">3.</span> Do not idle/AFK for more than 3 minutes.</li>
      <li><span class="rule-num">4.</span> No ghosting — do not give information to enemies.</li>
    </ul></div></div>
    <div class="rules-section"><h3>⚠️ Punishments</h3><div class="rules-list"><ul>
      <li><span class="rule-num">•</span> Warning — Minor offenses</li>
      <li><span class="rule-num">•</span> Kick — Repeated minor offenses</li>
      <li><span class="rule-num">•</span> Temp Ban (1-30 days) — Serious violations</li>
      <li><span class="rule-num">•</span> Permanent Ban — Hacking / severe abuse</li>
    </ul></div></div>
  </div>

  <!-- BAN LIST PAGE -->
  <div class="page" id="page-banlist">
    <div class="page-title">BAN LIST</div>
    <table class="data-table">
      <thead><tr><th>Nickname</th><th>Steam ID</th><th>Banned By</th><th>Reason</th><th>Duration</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($bans)): ?>
        <tr><td colspan="6" style="text-align:center;color:#777">No bans found</td></tr>
        <?php else: foreach($bans as $b): ?>
        <tr>
          <td><?= sanitize($b['nickname']) ?></td>
          <td style="font-size:11px;color:#888"><?= sanitize($b['steam_id']) ?></td>
          <td><?= sanitize($b['banned_by']) ?></td>
          <td><?= sanitize($b['reason']) ?></td>
          <td><span class="ban-badge <?= strpos(strtoupper($b['duration']),'PERM')!==false ? 'ban-perm' : 'ban-temp' ?>"><?= sanitize($b['duration']) ?></span></td>
          <td style="font-size:11px"><?= $b['ban_date'] ? date('d/m/Y', strtotime($b['ban_date'])) : '—' ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- GUNXP PAGE -->
  <div class="page" id="page-gunxp">
    <div class="page-title">GUNXP TOP PLAYERS</div>
    <table class="data-table">
      <thead><tr><th>#</th><th>Nickname</th><th>Level</th><th>XP</th><th>Kills</th><th>Deaths</th><th>K/D</th></tr></thead>
      <tbody>
        <?php if(empty($gunxpPlayers)): ?>
        <tr><td colspan="7" style="text-align:center;color:#777">No data yet</td></tr>
        <?php else: foreach($gunxpPlayers as $i => $p): $r=$i+1; ?>
        <tr class="<?= $r==1?'rank-1':($r==2?'rank-2':($r==3?'rank-3':'')) ?>">
          <td><?= getRankIcon($p['rank_num'] ?: $r) ?></td>
          <td><?= sanitize($p['nickname']) ?></td>
          <td><?= (int)$p['level'] ?></td>
          <td><?= number_format((int)$p['xp']) ?></td>
          <td><?= number_format((int)$p['kills']) ?></td>
          <td><?= number_format((int)$p['deaths']) ?></td>
          <td><?= $p['kd_ratio'] ?? getKD($p['kills'], $p['deaths']) ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- ACHIEVEMENTS PAGE -->
  <div class="page" id="page-achievements">
    <div class="page-title">ACHIEVEMENTS</div>
    <div class="ach-grid">
      <div class="ach-card"><span class="ach-icon">🔫</span><div class="ach-name">First Blood</div><div class="ach-desc">Get your first kill</div></div>
      <div class="ach-card"><span class="ach-icon">💀</span><div class="ach-name">Serial Killer</div><div class="ach-desc">Kill 1,000 players</div></div>
      <div class="ach-card"><span class="ach-icon">🎯</span><div class="ach-name">Headshot King</div><div class="ach-desc">500 headshots</div></div>
      <div class="ach-card ach-locked"><span class="ach-icon">🧟</span><div class="ach-name">Zombie Slayer</div><div class="ach-desc">Kill 500 zombies</div></div>
      <div class="ach-card ach-locked"><span class="ach-icon">🏆</span><div class="ach-name">Tournament Winner</div><div class="ach-desc">Win a tournament</div></div>
      <div class="ach-card ach-locked"><span class="ach-icon">🔥</span><div class="ach-name">On Fire</div><div class="ach-desc">20 kill streak</div></div>
      <div class="ach-card ach-locked"><span class="ach-icon">⚡</span><div class="ach-name">Speed Demon</div><div class="ach-desc">100 kills in one session</div></div>
      <div class="ach-card ach-locked"><span class="ach-icon">🛡️</span><div class="ach-name">Survivor</div><div class="ach-desc">Survive 50 zombie rounds</div></div>
    </div>
  </div>

  <!-- ZP STATS PAGE -->
  <div class="page" id="page-zpstats">
    <div class="page-title">ZOMBIE PLAGUE STATS</div>
    <table class="data-table">
      <thead><tr><th>#</th><th>Nickname</th><th>ZP Points</th><th>Zombie Kills</th><th>Human Wins</th><th>Nemesis</th><th>Survivals</th></tr></thead>
      <tbody>
        <?php if(empty($zpStats)): ?>
        <tr><td colspan="7" style="text-align:center;color:#777">No data yet</td></tr>
        <?php else: foreach($zpStats as $i => $s): $r=$i+1; ?>
        <tr>
          <td><?= getRankIcon($s['rank_num'] ?: $r) ?></td>
          <td><?= sanitize($s['nickname']) ?></td>
          <td><?= number_format((int)$s['zp_points']) ?></td>
          <td><?= number_format((int)$s['zombie_kills']) ?></td>
          <td><?= number_format((int)$s['human_wins']) ?></td>
          <td><?= number_format((int)$s['nemesis_kills']) ?></td>
          <td><?= number_format((int)$s['survive_rounds']) ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- VIP INFO PAGE -->
  <div class="page" id="page-vip">
    <div class="page-title">ORDER ADMIN / VIP</div>
    <div class="vip-box">
      <div class="vip-package">
        <h3>⭐ VIP Package</h3>
        <div class="vip-price">€5 <span>/ month &nbsp;|&nbsp; €12 / 3 months</span></div>
        <ul class="vip-features">
          <li>✅ Reserved slot on server</li>
          <li>✅ Custom [VIP] tag in-game</li>
          <li>✅ Double XP rate (+50%)</li>
          <li>✅ Access to VIP weapons</li>
          <li>✅ Special VIP skins</li>
        </ul>
        <button class="order-btn" onclick="openPayModal('vip_1m')">Order VIP Now</button>
      </div>
      <div class="vip-package admin">
        <h3>👑 Admin Package</h3>
        <div class="vip-price">€10 <span>/ month &nbsp;|&nbsp; €25 / 3 months</span></div>
        <ul class="vip-features">
          <li>✅ All VIP benefits included</li>
          <li>✅ Admin tag [ADMIN] in-game</li>
          <li>✅ Kick / warn / mute players</li>
          <li>✅ Change maps</li>
          <li>✅ Must be active for 2 weeks</li>
        </ul>
        <button class="order-btn admin-btn" onclick="openPayModal('admin_1m')">Order Admin Now</button>
      </div>
    </div>
    <div style="background:#0d0d0d;border:1px solid #333;padding:14px;margin-top:14px;font-size:13px;color:#aaa;">
      <strong style="color:#fff">📌 How to Order:</strong><br>
      1. Click the order button and choose your package<br>
      2. Select payment method (₿ BTC / Ξ ETH / 💵 USDT / 💬 Discord)<br>
      3. Complete payment and send proof to Discord: <a href="<?= sanitize($discordLink) ?>" target="_blank" style="color:#5865F2"><?= sanitize($discordLink) ?></a><br>
      4. VIP/Admin will be activated within <strong>24 hours</strong>
    </div>
  </div>

  <!-- CONTACT PAGE -->
  <div class="page" id="page-contact">
    <div class="page-title">CONTACT SUPER ADMINS</div>
    <div class="admin-cards">
      <div class="admin-card">
        <div class="admin-avatar">SA</div>
        <div class="admin-info">
          <div class="name">SuperAdmin</div>
          <div class="role">⭐ Super Administrator</div>
          <div class="status">● Online</div>
        </div>
      </div>
      <div class="admin-card">
        <div class="admin-avatar">AX</div>
        <div class="admin-info">
          <div class="name">Admin_X</div>
          <div class="role">👑 Senior Admin</div>
          <div class="status" style="color:#888">● Offline</div>
        </div>
      </div>
    </div>
    <div style="background:#0d0d0d;border:1px solid #5865F2;padding:12px;border-radius:4px;margin-bottom:14px;text-align:center;">
      <strong style="color:#5865F2">💬 Join our Discord for fastest response!</strong><br>
      <a href="<?= sanitize($discordLink) ?>" target="_blank" style="color:#fff;font-weight:bold;"><?= sanitize($discordLink) ?></a>
    </div>
    <div class="contact-form">
      <h3>📩 Send Message to Admin Team</h3>
      <div class="form-row"><label>Your Nickname *</label><input type="text" id="contact_nickname" placeholder="Your in-game nickname"></div>
      <div class="form-row"><label>Your Email *</label><input type="email" id="contact_email" placeholder="your@email.com"></div>
      <div class="form-row"><label>Subject</label>
        <select id="contact_subject">
          <option>Ban Appeal</option>
          <option>Report Cheater</option>
          <option>Report Admin Abuse</option>
          <option>Order VIP/Admin</option>
          <option>Technical Issue</option>
          <option>Other</option>
        </select>
      </div>
      <div class="form-row"><label>Message *</label><textarea id="contact_message" rows="5" placeholder="Describe your issue in detail (min 10 characters)..."></textarea></div>
      <button class="submit-btn" onclick="sendContact()">Send Message</button>
    </div>
  </div>

</div><!-- /main -->

<!-- ┌─ RIGHT COLUMN ──────────────────────────────────────────── -->
<div class="right-col">

  <div class="box-title">Account</div>
  <div class="login-box" id="login-form">
    <input type="text" id="login_username" placeholder="Username">
    <input type="password" id="login_password" placeholder="Password">
    <div class="login-row"><button class="login-btn" onclick="doLogin()">Login</button></div>
    <div class="login-links">
      <a onclick="showRegisterForm()" style="cursor:pointer">Create Account</a> |
      <a onclick="openProfileModal('recover')" style="cursor:pointer">Forgot Password?</a>
    </div>
    <div id="register-form" style="display:none;margin-top:8px;">
      <input type="text" id="reg_username" placeholder="Username (min 3)" style="margin-bottom:5px">
      <input type="password" id="reg_password" placeholder="Password (min 4)" style="margin-bottom:5px">
      <input type="email" id="reg_email" placeholder="Email (optional)" style="margin-bottom:5px">
      <button class="login-btn" onclick="doRegister()" style="width:100%">Register</button>
    </div>
  </div>
  <div class="logged-in" id="logged-in-box" style="display:none">
    <p>Welcome, <strong id="logged-user"></strong>!</p>
    <div id="user-badges" style="margin-bottom:4px;"></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">
      <button class="logout-btn" onclick="doLogout()">Logout</button>
      <button class="logout-btn" style="background:#1a1a2e;border-color:#444" onclick="openProfileModal()">✏ Profile</button>
      <button class="logout-btn" style="background:#0a1a0a;border-color:#336" onclick="openChatModal()">💬 Chat <span id="unread-badge" style="display:none;background:#cc0000;padding:0 4px;border-radius:3px;font-size:10px"><?= $unreadCount ?: '' ?></span></button>
    </div>
  </div>

  <div class="box-title">Server Status</div>
  <div class="server-status-box">
    <div class="status-row"><span>GunXP Server</span><span class="status-online">● ONLINE</span></div>
    <div class="status-row"><span>IP</span><span style="font-size:11px"><?= sanitize($gunxpIp) ?></span></div>
    <div class="status-row"><span>ZP Server</span><span class="status-online">● ONLINE</span></div>
    <div class="status-row"><span>IP</span><span style="font-size:11px"><?= sanitize($zpIp) ?></span></div>
  </div>

  <div class="box-title">Shoutbox</div>
  <div id="shout-messages" style="max-height:200px;overflow-y:auto;"></div>
  <div class="shout-input-area" id="shout-input-area">
    <div style="text-align:center;padding:6px;color:#777;font-size:12px;">Login to post</div>
  </div>

  <div class="box-title">Quick Links</div>
  <div style="padding:8px;">
    <a onclick="showPage('gunxp')" style="display:block;font-size:12px;color:#00008B;margin:4px 0;cursor:pointer">▶ GunXP Top Players</a>
    <a onclick="showPage('zpstats')" style="display:block;font-size:12px;color:#00008B;margin:4px 0;cursor:pointer">▶ ZP Stats</a>
    <a onclick="showPage('banlist')" style="display:block;font-size:12px;color:#00008B;margin:4px 0;cursor:pointer">▶ Ban List</a>
    <a onclick="showPage('warnings')" style="display:block;font-size:12px;color:#00008B;margin:4px 0;cursor:pointer">▶ Warnings</a>
    <a onclick="openPayModal()" style="display:block;font-size:12px;color:#CC0000;font-weight:bold;margin:4px 0;cursor:pointer">▶ Order VIP / Admin</a>
    <a href="<?= sanitize($discordLink) ?>" target="_blank" style="display:block;font-size:12px;color:#5865F2;font-weight:bold;margin:4px 0;">▶ Join Discord</a>
  </div>

</div><!-- /right-col -->

</div><!-- /wrap -->

<!-- ══ FOOTER ═════════════════════════════════════════════════ -->
<div class="footer">
  ZXP.lt Gaming &copy; <?= date('Y') ?> &nbsp;|&nbsp;
  CS 1.6 GunXP &amp; Zombie Plague &nbsp;|&nbsp;
  <a onclick="showPage('contact')" style="cursor:pointer">Contact</a> &nbsp;|&nbsp;
  <a onclick="showPage('rules')" style="cursor:pointer">Rules</a> &nbsp;|&nbsp;
  <a href="<?= sanitize($discordLink) ?>" target="_blank">Discord</a> &nbsp;|&nbsp;
  <a onclick="openPayModal()" style="cursor:pointer;color:#ffcc00">💎 Donate</a>
</div>

<script>
// PHP vars passed to JS
const DISCORD_LINK = '<?= addslashes($discordLink) ?>';
const ADMIN_EMAIL  = '<?= addslashes($adminEmail) ?>';
const BTC_WALLET   = '<?= addslashes($btcWallet) ?>';
const ETH_WALLET   = '<?= addslashes($ethWallet) ?>';
const USDT_WALLET  = '<?= addslashes($usdtWallet) ?>';
<?php if(isLoggedIn()): ?>
// Auto-login state from PHP session
let currentUser = '<?= addslashes($_SESSION['username']) ?>';
let currentUserId = <?= (int)$_SESSION['user_id'] ?>;
let isAdmin = <?= (int)$_SESSION['is_admin'] ?>;
let isSuperAdmin = <?= (int)($_SESSION['is_super_admin'] ?? 0) ?>;
let isVip = <?= (int)$_SESSION['is_vip'] ?>;

document.getElementById('login-form').style.display    = 'none';
document.getElementById('logged-in-box').style.display = 'block';
document.getElementById('logged-user').textContent     = currentUser;

// Show badges
const badges = document.getElementById('user-badges');
if(isSuperAdmin) badges.innerHTML += '<span style="color:#ff4444;font-size:11px;font-weight:bold">⭐ Super Admin</span> ';
else if(isAdmin) badges.innerHTML += '<span style="color:#cc0000;font-size:11px">👑 Admin</span> ';
if(isVip) badges.innerHTML += '<span style="color:#ffcc00;font-size:11px">⭐ VIP</span>';

document.getElementById('members-online').innerHTML    = '▶ Members: <strong>1</strong>';
document.getElementById('shout-input-area').innerHTML  =
  '<input type="text" id="shout_msg" placeholder="Say something..." maxlength="200">' +
  '<button onclick="postShout()">Post</button>';

// Show unread badge
const unread = <?= $unreadCount ?>;
if(unread > 0) {
  document.getElementById('unread-badge').style.display = 'inline';
  document.getElementById('unread-badge').textContent   = unread;
}
<?php else: ?>
let currentUser = null;
let currentUserId = 0;
let isAdmin = 0;
let isSuperAdmin = 0;
let isVip = 0;
<?php endif; ?>
</script>
<script src="assets/js/script.js"></script>

</body>
</html>

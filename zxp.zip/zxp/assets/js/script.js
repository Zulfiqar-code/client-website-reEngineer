// assets/js/script.js — ZXP.lt v2.0
// ══════════════════════════════════════════════════════════════

// ── MODAL ─────────────────────────────────────────────────────
const modal      = document.getElementById('modal');
const modalTitle = document.getElementById('modal-title');
const modalMsg   = document.getElementById('modal-msg');

function showModal(title, msg) {
    modalTitle.textContent = title;
    modalMsg.innerHTML = msg;
    modal.classList.add('show');
}
function closeModal() { modal.classList.remove('show'); }

// ── PAGE NAV ──────────────────────────────────────────────────
function showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const t = document.getElementById(`page-${id}`);
    if (t) t.classList.add('active');
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    const navMap = { warnings:'nav-warnings', rules:'nav-rules', banlist:'nav-banlist',
                     gunxp:'nav-gunxp', achievements:'nav-ach', zpstats:'nav-zp', contact:'nav-contact' };
    if (navMap[id]) { const el = document.getElementById(navMap[id]); if(el) el.classList.add('active'); }
    window.scrollTo(0, 0);
}

// ── REGISTER TOGGLE ───────────────────────────────────────────
function showRegisterForm() {
    const f = document.getElementById('register-form');
    if (f) f.style.display = f.style.display === 'none' ? 'block' : 'none';
}

// ── LOGIN ─────────────────────────────────────────────────────
async function doLogin() {
    const username = document.getElementById('login_username')?.value.trim();
    const password = document.getElementById('login_password')?.value.trim();
    if (!username || !password) { showModal('Error','Enter username and password'); return; }
    try {
        const data = await post({ action:'login', username, password });
        if (data.success) {
            currentUser   = data.username;
            currentUserId = data.user_id || 0;
            isAdmin       = data.is_admin ? 1 : 0;
            isSuperAdmin  = data.is_super_admin ? 1 : 0;
            isVip         = data.is_vip ? 1 : 0;
            document.getElementById('logged-user').textContent     = data.username;
            document.getElementById('login-form').style.display    = 'none';
            document.getElementById('logged-in-box').style.display = 'block';
            document.getElementById('members-online').innerHTML    = '▶ Members: <strong>1</strong>';
            document.getElementById('shout-input-area').innerHTML  =
                '<input type="text" id="shout_msg" placeholder="Say something..." maxlength="200">' +
                '<button onclick="postShout()">Post</button>';
            // Badges
            const badges = document.getElementById('user-badges');
            badges.innerHTML = '';
            if(data.is_super_admin) badges.innerHTML += '<span style="color:#ff4444;font-size:11px;font-weight:bold">⭐ Super Admin</span> ';
            else if(data.is_admin) badges.innerHTML += '<span style="color:#cc0000;font-size:11px">👑 Admin</span> ';
            if(data.is_vip) badges.innerHTML += '<span style="color:#ffcc00;font-size:11px">⭐ VIP</span>';
            // Unread messages
            if (data.unread_count > 0) {
                const ub = document.getElementById('unread-badge');
                if(ub) { ub.style.display='inline'; ub.textContent = data.unread_count; }
            }
            showModal('Welcome Back!', `Welcome ${data.username}!`);
        } else {
            showModal('Login Failed', data.error);
        }
    } catch(e) { showModal('Error','Something went wrong. Try again.'); }
}

// ── REGISTER ──────────────────────────────────────────────────
async function doRegister() {
    const username = document.getElementById('reg_username')?.value.trim();
    const password = document.getElementById('reg_password')?.value.trim();
    const email    = document.getElementById('reg_email')?.value.trim();
    if (!username || !password) { showModal('Error','Fill required fields'); return; }
    if (username.length < 3) { showModal('Error','Username 3+ chars'); return; }
    if (password.length < 4) { showModal('Error','Password 4+ chars'); return; }
    try {
        const data = await post({ action:'register', username, password, email });
        if (data.success) {
            showModal('Success!','Account created! You can now login.');
            document.getElementById('register-form').style.display = 'none';
            ['reg_username','reg_password','reg_email'].forEach(id => { const el=document.getElementById(id); if(el)el.value=''; });
        } else { showModal('Register Failed', data.error); }
    } catch(e) { showModal('Error','Something went wrong.'); }
}

// ── LOGOUT ────────────────────────────────────────────────────
async function doLogout() {
    await post({ action:'logout' }).catch(()=>{});
    currentUser = null; currentUserId = 0;
    document.getElementById('login-form').style.display    = 'block';
    document.getElementById('logged-in-box').style.display = 'none';
    document.getElementById('members-online').innerHTML    = '▶ Members: <strong>0</strong>';
    document.getElementById('shout-input-area').innerHTML  = '<div style="text-align:center;padding:4px;">Login to post</div>';
    document.getElementById('login_username').value = '';
    document.getElementById('login_password').value = '';
    showModal('Logged Out','You have been logged out.');
}

// ── SHOUTBOX ──────────────────────────────────────────────────
async function postShout() {
    const msg = document.getElementById('shout_msg')?.value.trim();
    if (!msg) { showModal('Error','Enter a message'); return; }
    if (msg.length > 200) { showModal('Error','Max 200 chars'); return; }
    const data = await post({ action:'shout', message:msg });
    if (data.success) { document.getElementById('shout_msg').value=''; loadShouts(); }
    else showModal('Error', data.error);
}

async function loadShouts() {
    try {
        const data = await post({ action:'get_shouts' });
        if (!data.success) return;
        const box = document.getElementById('shout-messages');
        if (!box) return;
        if (!data.shouts.length) { box.innerHTML='<div style="color:#555;padding:6px;text-align:center">No messages yet</div>'; return; }
        box.innerHTML = data.shouts.map(s => {
            let badge = '';
            if (s.is_super_admin == 1) badge = '<span style="color:#ff4444;font-size:10px">⭐SA</span> ';
            else if (s.is_admin == 1)  badge = '<span style="color:#cc0000;font-size:10px">👑A</span> ';
            else if (s.is_vip == 1)    badge = '<span style="color:#ffcc00;font-size:10px">⭐V</span> ';
            return `<div class="shout-item">
                <span class="shout-user">${badge}<b>${escapeHtml(s.username)}</b></span>
                <span class="shout-time">${timeAgoJs(s.created_at)}</span>
                <div class="shout-text">${escapeHtml(s.message)}</div>
            </div>`;
        }).join('');
        box.scrollTop = 0;
    } catch(e) {}
}

// ── CONTACT ───────────────────────────────────────────────────
async function sendContact() {
    const nickname = document.getElementById('contact_nickname')?.value.trim();
    const email    = document.getElementById('contact_email')?.value.trim();
    const subject  = document.getElementById('contact_subject')?.value.trim();
    const message  = document.getElementById('contact_message')?.value.trim();
    if (!nickname||!email||!message) { showModal('Error','Fill all required fields'); return; }
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) { showModal('Error','Invalid email'); return; }
    const data = await post({ action:'contact', nickname, email, subject, message });
    if (data.success) {
        showModal('Sent!','Message sent! Admin will reply within 24 hours.');
        document.getElementById('contact_nickname').value='';
        document.getElementById('contact_email').value='';
        document.getElementById('contact_message').value='';
    } else showModal('Error', data.error);
}

// ── GUEST COUNT ───────────────────────────────────────────────
async function updateGuestCount() {
    try {
        const data = await post({ action:'get_guest_count' });
        const el = document.getElementById('guest-count');
        if (el && data.count) el.textContent = data.count;
    } catch(e) {}
}

// ══ PAYMENT MODAL (Crypto + Discord) ══════════════════════════
let selectedMethod = '';

function openPayModal(defaultPkg) {
    if (defaultPkg) { const s=document.getElementById('pay_package'); if(s) s.value=defaultPkg; }
    document.getElementById('pay-step-1').style.display = 'block';
    document.getElementById('pay-step-2').style.display = 'none';
    selectedMethod = '';
    ['crypto_btc','crypto_eth','crypto_usdt','discord'].forEach(m => {
        const el = document.getElementById('lbl-'+m);
        if(el) el.style.border = '1px solid #444';
    });
    document.getElementById('payment-modal').classList.add('show');
}

function closePayModal() { document.getElementById('payment-modal').classList.remove('show'); }

function selectMethod(method) {
    selectedMethod = method;
    ['crypto_btc','crypto_eth','crypto_usdt','discord'].forEach(m => {
        const el = document.getElementById('lbl-'+m);
        if(el) el.style.border = m===method ? '2px solid #cc0000' : '1px solid #444';
    });
}

async function submitOrder() {
    const username = document.getElementById('pay_username')?.value.trim();
    const pkg      = document.getElementById('pay_package')?.value;
    if (!username) { showModal('Error','Enter your in-game nickname'); return; }
    if (!selectedMethod) { showModal('Error','Select a payment method'); return; }
    try {
        const data = await post({ action:'order_vip', username, package:pkg, method:selectedMethod });
        if (data.success) {
            document.getElementById('pay-step-1').style.display = 'none';
            document.getElementById('pay-step-2').style.display = 'block';
            document.getElementById('pay-modal-title').textContent = '✅ Order #'+data.order_id+' Created!';
            const pkgNames = { vip_1m:'VIP 1 Month', vip_3m:'VIP 3 Months', admin_1m:'Admin 1 Month', admin_3m:'Admin 3 Months' };
            let html = `<div class="order-confirm-box">
                <p style="color:#4f4;font-weight:bold">Order confirmed! Amount: <span style="color:#ffcc00">€${data.amount}</span></p>
                <p style="color:#aaa;font-size:13px">Package: ${pkgNames[pkg]||pkg}</p>
                <p style="color:#aaa;font-size:13px">Nickname: ${escapeHtml(username)}</p>
            </div>`;

            if (data.method === 'crypto_btc') {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#f7931a">₿ Bitcoin (BTC) Payment</p>
                    <p style="color:#aaa;font-size:12px;margin-bottom:6px">Send exactly <strong style="color:#ffcc00">€${data.amount} worth of BTC</strong> to:</p>
                    <div class="wallet-address" onclick="copyWallet(this)" title="Click to copy">${escapeHtml(data.wallet)}</div>
                    <p style="color:#aaa;font-size:12px;margin-top:8px">After payment, send screenshot to Discord:</p>
                    <a href="${DISCORD_LINK}" target="_blank" class="discord-btn">Join Discord →</a>
                    <p style="color:#666;font-size:11px;margin-top:6px">Reference: ${escapeHtml(data.note)}</p>
                </div>`;
            } else if (data.method === 'crypto_eth') {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#627eea">Ξ Ethereum (ETH) Payment</p>
                    <p style="color:#aaa;font-size:12px;margin-bottom:6px">Send exactly <strong style="color:#ffcc00">€${data.amount} worth of ETH</strong> to:</p>
                    <div class="wallet-address" onclick="copyWallet(this)" title="Click to copy">${escapeHtml(data.wallet)}</div>
                    <p style="color:#aaa;font-size:12px;margin-top:8px">After payment, send screenshot to Discord:</p>
                    <a href="${DISCORD_LINK}" target="_blank" class="discord-btn">Join Discord →</a>
                    <p style="color:#666;font-size:11px;margin-top:6px">Reference: ${escapeHtml(data.note)}</p>
                </div>`;
            } else if (data.method === 'crypto_usdt') {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#26a17b">💵 USDT (TRC20) Payment</p>
                    <p style="color:#aaa;font-size:12px;margin-bottom:6px">Send exactly <strong style="color:#ffcc00">$${data.amount} USDT (TRC20)</strong> to:</p>
                    <div class="wallet-address" onclick="copyWallet(this)" title="Click to copy">${escapeHtml(data.wallet)}</div>
                    <p style="color:#aaa;font-size:12px;margin-top:8px">After payment, send screenshot to Discord:</p>
                    <a href="${DISCORD_LINK}" target="_blank" class="discord-btn">Join Discord →</a>
                    <p style="color:#666;font-size:11px;margin-top:6px">Reference: ${escapeHtml(data.note)}</p>
                </div>`;
            } else if (data.method === 'paypal') {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#009cde">🅿 PayPal Checkout</p>
                    <p style="color:#aaa;font-size:13px;margin-bottom:12px">You'll be redirected to PayPal to complete your <strong style="color:#ffcc00">€${data.amount}</strong> payment securely.</p>
                    <a href="${escapeHtml(data.paypal_url)}" target="_blank" class="submit-btn" style="display:inline-block;text-decoration:none;background:#009cde;padding:10px 20px;">Pay with PayPal →</a>
                    <p style="color:#666;font-size:11px;margin-top:10px">After payment, your VIP/Admin will be activated within 24h.<br>Order #${data.order_id}</p>
                </div>`;
            } else if (data.method === 'stripe') {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#635bff">💳 Card Payment (Stripe)</p>
                    <p style="color:#aaa;font-size:13px;margin-bottom:12px">You'll be redirected to a secure Stripe page to pay <strong style="color:#ffcc00">€${data.amount}</strong> by card.</p>
                    <a href="${escapeHtml(data.stripe_url)}" target="_blank" class="submit-btn" style="display:inline-block;text-decoration:none;background:#635bff;padding:10px 20px;">Pay by Card →</a>
                    <p style="color:#666;font-size:11px;margin-top:10px">Powered by Stripe. Card details never stored.<br>Order #${data.order_id}</p>
                </div>`;
            } else {
                html += `<div class="crypto-pay-box">
                    <p style="font-weight:bold;margin-bottom:8px;color:#5865F2">💬 Discord Payment</p>
                    <p style="color:#aaa;font-size:13px;margin-bottom:10px">Contact an admin on Discord to arrange payment:</p>
                    <a href="${DISCORD_LINK}" target="_blank" class="discord-btn" style="font-size:15px">Join Our Discord Server →</a>
                    <p style="color:#777;font-size:12px;margin-top:10px">Reference: <strong style="color:#fff">${escapeHtml(data.note)}</strong></p>
                </div>`;
            }
            html += `<p style="color:#666;font-size:12px;margin-top:12px">VIP/Admin activated within 24h after payment confirmation.</p>`;
            document.getElementById('pay-instructions').innerHTML = html;
        } else {
            showModal('Order Failed', data.error || 'Something went wrong');
        }
    } catch(e) { showModal('Error','Request failed. Try again.'); }
}

function copyWallet(el) {
    navigator.clipboard.writeText(el.textContent.trim()).then(() => {
        const orig = el.style.background;
        el.style.background = '#003300';
        el.title = '✅ Copied!';
        setTimeout(() => { el.style.background=orig; el.title='Click to copy'; }, 1500);
    }).catch(() => showModal('Copy','Copy manually: '+el.textContent));
}

// ══ PRIVATE CHAT (User to User) ═══════════════════════════════
let chatWithId   = null;
let chatWithName = '';
let chatInterval = null;
let allChatUsers = [];

function openChatModal() {
    if (!currentUser) { showModal('Error','Please login first'); return; }
    document.getElementById('chat-modal').classList.add('show');
    loadChatUsers();
}

function closeChatModal() {
    document.getElementById('chat-modal').classList.remove('show');
    if (chatInterval) { clearInterval(chatInterval); chatInterval=null; }
    chatWithId = null;
}

async function loadChatUsers() {
    try {
        const data = await post({ action:'get_users_list' });
        if (!data.success) return;
        allChatUsers = data.users;
        renderChatUsers(allChatUsers);
    } catch(e) {}
}

function renderChatUsers(users) {
    const box = document.getElementById('chat-users-list');
    if (!users.length) { box.innerHTML='<div style="color:#555;padding:10px;text-align:center;font-size:12px">No other users yet</div>'; return; }
    box.innerHTML = users.map(u => {
        let badge = '';
        if (u.is_super_admin == 1) badge = ' <span style="color:#ff4444;font-size:9px">SA</span>';
        else if (u.is_admin == 1)  badge = ' <span style="color:#cc0000;font-size:9px">A</span>';
        else if (u.is_vip == 1)    badge = ' <span style="color:#ffcc00;font-size:9px">V</span>';
        return `<div class="chat-user-item ${chatWithId==u.id?'active':''}" onclick="openChatWith(${u.id},'${escapeHtml(u.username).replace(/'/g,"\\'")}')">
            <span class="chat-user-avatar">${u.username.charAt(0).toUpperCase()}</span>
            <span>${escapeHtml(u.username)}${badge}</span>
        </div>`;
    }).join('');
}

function filterChatUsers() {
    const q = document.getElementById('chat-user-search').value.toLowerCase();
    renderChatUsers(allChatUsers.filter(u => u.username.toLowerCase().includes(q)));
}

function openChatWith(userId, userName) {
    chatWithId   = userId;
    chatWithName = userName;
    document.getElementById('chat-no-select').style.display = 'none';
    document.getElementById('chat-active').style.display    = 'flex';
    document.getElementById('chat-with-name').textContent   = '💬 ' + userName;
    renderChatUsers(allChatUsers);
    loadChatMessages();
    if (chatInterval) clearInterval(chatInterval);
    chatInterval = setInterval(loadChatMessages, 5000);
}

async function loadChatMessages() {
    if (!chatWithId) return;
    try {
        const data = await post({ action:'get_pm', with_user:chatWithId });
        if (!data.success) return;
        const box = document.getElementById('chat-messages-box');
        const wasAtBottom = box.scrollHeight - box.scrollTop <= box.clientHeight + 30;
        box.innerHTML = data.messages.map(m => {
            const mine = (m.sender_id == data.my_id || m.sender_id == currentUserId);
            return `<div class="chat-bubble ${mine?'mine':'theirs'}" id="pm-${m.id}">
                ${!mine ? `<div class="chat-bubble-name">${escapeHtml(m.sender_name)}</div>` : ''}
                <div class="chat-bubble-text">${escapeHtml(m.message)}</div>
                <div class="chat-bubble-time">
                    ${timeAgoJs(m.created_at)}
                    <span onclick="deletePm(${m.id})" style="margin-left:8px;cursor:pointer;color:#aa3333;font-size:10px;opacity:0.6" title="Delete">🗑</span>
                </div>
            </div>`;
        }).join('');
        if (wasAtBottom || !data.messages.length) box.scrollTop = box.scrollHeight;
        const ub = document.getElementById('unread-badge');
        if(ub) { ub.style.display='none'; ub.textContent=''; }
    } catch(e) {}
}

async function deletePm(msgId) {
    try {
        const data = await post({ action:'delete_pm', msg_id:msgId });
        if (data.success) {
            const el = document.getElementById(`pm-${msgId}`);
            if (el) el.remove();
        }
    } catch(e) {}
}

async function sendChatMsg() {
    if (!chatWithId) return;
    const input = document.getElementById('chat-input-msg');
    const msg   = input?.value.trim();
    if (!msg) return;
    input.value = '';
    try {
        const data = await post({ action:'send_pm', receiver_id:chatWithId, message:msg });
        if (data.success) loadChatMessages();
        else showModal('Error', data.error || 'Failed to send');
    } catch(e) {}
}

// Poll unread count
async function pollUnread() {
    if (!currentUser) return;
    try {
        const data = await post({ action:'get_unread' });
        if (data.success) {
            const ub = document.getElementById('unread-badge');
            if(ub) {
                if (data.count > 0) { ub.style.display='inline'; ub.textContent=data.count; }
                else ub.style.display='none';
            }
        }
    } catch(e) {}
}

// ══ PROFILE MODAL ═════════════════════════════════════════════
function openProfileModal(tab) {
    document.getElementById('profile-modal').classList.add('show');
    if (tab === 'recover') switchProfileTab('recover');
    else switchProfileTab('profile');
}
function closeProfileModal() { document.getElementById('profile-modal').classList.remove('show'); }

function switchProfileTab(tab) {
    document.getElementById('profile-tab-profile').style.display = tab==='profile' ? 'block' : 'none';
    document.getElementById('profile-tab-recover').style.display = tab==='recover' ? 'block' : 'none';
    document.getElementById('tab-profile').classList.toggle('active', tab==='profile');
    document.getElementById('tab-recover').classList.toggle('active', tab==='recover');
}

async function updateProfile() {
    const new_username      = document.getElementById('prof_new_username')?.value.trim();
    const new_password      = document.getElementById('prof_new_password')?.value;
    const current_password  = document.getElementById('prof_current_password')?.value;
    if (!current_password) { showModal('Error','Enter your current password'); return; }
    try {
        const data = await post({ action:'update_profile', new_username, new_password, current_password });
        if (data.success) {
            showModal('Saved!','Profile updated successfully!');
            if (data.new_username) {
                currentUser = data.new_username;
                document.getElementById('logged-user').textContent = data.new_username;
            }
            closeProfileModal();
        } else showModal('Error', data.error);
    } catch(e) { showModal('Error','Something went wrong.'); }
}

async function doGoogleRecover() {
    const email = document.getElementById('recover_email')?.value.trim();
    if (!email) { showModal('Error','Enter your email'); return; }
    try {
        const data = await post({ action:'google_auth_link', email });
        if (data.success) {
            let msg = data.message || 'Recovery initiated!';
            if (data.discord) msg += `<br><br>Or contact us on Discord: <a href="${DISCORD_LINK}" target="_blank" style="color:#5865F2">${DISCORD_LINK}</a>`;
            showModal('Recovery', msg);
            closeProfileModal();
        } else showModal('Error', data.error);
    } catch(e) { showModal('Error','Something went wrong.'); }
}

// ══ AI CHATBOT ════════════════════════════════════════════════
let chatbotOpen = false;
let chatbotHistory = [];
const CHATBOT_SYSTEM = `You are ZXP Gaming Assistant, a helpful chatbot for ZXP.lt — a Counter-Strike 1.6 gaming server.
Server IP: 135.125.147.173:27017
Discord: discord.gg/BSp88gJmpx
Payment: Crypto (BTC/ETH/USDT) or Discord. NO PayPal.
VIP costs: €5/month, €12/3months. Admin: €10/month, €25/3months.
VIP perks: reserved slot, custom tag, double XP, VIP weapons, skins.
Admin perks: all VIP + kick/warn/mute players, change maps.
To connect in CS 1.6: open console, type: connect 135.125.147.173:27017
Rules: no hacks, no racism, no spam, respect admins.
Keep replies short, friendly, gaming-focused. Use emojis sparingly.`;

function toggleChatbot() {
    chatbotOpen = !chatbotOpen;
    document.getElementById('chatbot-box').style.display = chatbotOpen ? 'flex' : 'none';
    if (chatbotOpen) document.getElementById('chatbot-input').focus();
}

async function sendBotMsg() {
    const input = document.getElementById('chatbot-input');
    const msg   = input.value.trim();
    if (!msg) return;
    input.value = '';

    appendBotMsg(msg, 'user');
    chatbotHistory.push({ role:'user', content:msg });

    const thinkingId = 'bot-thinking-' + Date.now();
    appendBotMsg('...', 'bot', thinkingId);

    try {
        const resp = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 300,
                system: CHATBOT_SYSTEM,
                messages: chatbotHistory
            })
        });
        const data = await resp.json();
        const reply = data.content?.[0]?.text || 'Sorry, I could not understand that.';
        chatbotHistory.push({ role:'assistant', content:reply });
        // Remove thinking bubble
        const el = document.getElementById(thinkingId);
        if (el) el.remove();
        appendBotMsg(reply, 'bot');
    } catch(e) {
        const el = document.getElementById(thinkingId);
        if(el) el.remove();
        appendBotMsg('Connection error. For help join Discord: discord.gg/BSp88gJmpx', 'bot');
    }
}

function appendBotMsg(text, role, id) {
    const box = document.getElementById('chatbot-messages');
    const div = document.createElement('div');
    div.className = 'chatbot-msg ' + role;
    div.textContent = text;
    if (id) div.id = id;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

// ── HELPERS ───────────────────────────────────────────────────
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function timeAgoJs(dt) {
    if (!dt) return '';
    const diff = Math.floor((Date.now() - new Date(dt).getTime()) / 1000);
    if (diff < 60)     return diff + 's ago';
    if (diff < 3600)   return Math.floor(diff/60) + 'm ago';
    if (diff < 86400)  return Math.floor(diff/3600) + 'h ago';
    return Math.floor(diff/86400) + 'd ago';
}

async function post(data) {
    const body = new URLSearchParams(data).toString();
    const res  = await fetch('ajax/handler.php', {
        method: 'POST',
        headers: { 'Content-Type':'application/x-www-form-urlencoded', 'X-Requested-With':'XMLHttpRequest' },
        body
    });
    return res.json();
}

// ── EVENTS ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    // Close modals on overlay click
    ['modal','payment-modal','chat-modal','profile-modal'].forEach(id => {
        const el = document.getElementById(id);
        if(el) el.addEventListener('click', e => {
            if (e.target === el) {
                if (id==='modal') closeModal();
                else if (id==='payment-modal') closePayModal();
                else if (id==='chat-modal') closeChatModal();
                else if (id==='profile-modal') closeProfileModal();
            }
        });
    });

    loadShouts();
    setInterval(loadShouts, 30000);
    setInterval(updateGuestCount, 8000);
    if (currentUser) setInterval(pollUnread, 15000);

    // Load forum when forum page is shown
    document.querySelectorAll('[onclick]').forEach(el => {
        const orig = el.getAttribute('onclick');
        if (orig && orig.includes("showPage('forum')")) {
            el.setAttribute('onclick', "showPage('forum'); loadForumCategories();");
        }
    });
});

document.addEventListener('keypress', e => {
    if (e.key === 'Enter') {
        const id = document.activeElement?.id;
        if (id === 'login_password') doLogin();
        else if (id === 'shout_msg') postShout();
        else if (id === 'chat-input-msg') sendChatMsg();
    }
});




// ══ FORUM — PHOBIA STYLE ══════════════════════════════════════
let currentCategoryId = null;
let currentThreadId   = null;
let currentThreadData = null;

// Avatar color from username initial
function avatarColor(name) {
    const colors = ['#7c3aed','#cc0000','#0066cc','#00885a','#aa6600','#883388'];
    let h = 0;
    for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffffffff;
    return colors[Math.abs(h) % colors.length];
}

function makeAvatar(name, cls = '') {
    const c = avatarColor(name);
    return `<div class="forum-post-avatar ${cls}" style="background:linear-gradient(135deg,${c},${c}99)">${escapeHtml(name.charAt(0).toUpperCase())}</div>`;
}

function makeLpAvatar(name) {
    const c = avatarColor(name);
    return `<div class="lp-avatar" style="background:linear-gradient(135deg,${c},${c}99)">${escapeHtml(name.charAt(0).toUpperCase())}</div>`;
}

// ── Category list (PHOBIA style) ──────────────────────────────
async function loadForumCategories() {
    const container = document.getElementById('forum-categories');
    if (!container) return;
    container.innerHTML = '<div style="padding:30px;text-align:center;color:#555">Loading forum...</div>';
    try {
        const data = await forumPost({ action: 'get_categories' });
        if (!data.success || !data.categories.length) {
            container.innerHTML = '<div style="padding:30px;text-align:center;color:#555">Forum unavailable.</div>';
            return;
        }

        container.innerHTML = `
        <div class="forum-group">
            <div class="forum-group-header">
                <h2>💬 Community Forum</h2>
                ${currentUser ? `<span class="forum-new-thread-btn" onclick="showNewThreadForm(null)">+ New Thread</span>` : ''}
            </div>
            ${data.categories.map(cat => {
                const lp = cat.last_post;
                const canPost = !cat.is_locked && (!cat.is_admin_only || isAdmin);
                return `
                <div class="forum-category-row">
                    <div class="forum-cat-icon">💬</div>
                    <div class="forum-cat-info">
                        <h3 onclick="loadCategoryView(${cat.id}, '${escapeHtml(cat.name).replace(/'/g,"\\'")}')">
                            ${escapeHtml(cat.name)}
                            ${cat.is_locked ? '<span style="color:#555;font-size:10px;margin-left:6px">🔒 Locked</span>' : ''}
                        </h3>
                        <p>${escapeHtml(cat.description || '')}</p>
                        ${canPost && currentUser ? `<span class="forum-new-thread-btn" onclick="showNewThreadForm(${cat.id})">+ Post</span>` : ''}
                    </div>
                    <div class="forum-cat-stats">
                        <span class="stat-num">${cat.post_count ?? 0}</span>
                        <span class="stat-label">posts</span>
                    </div>
                    <div class="forum-cat-lastpost">
                        ${lp ? `
                            ${makeLpAvatar(lp.username)}
                            <div class="lp-info">
                                <span class="lp-title" onclick="showThread(${lp.thread_id})">${escapeHtml(lp.thread_title)}</span>
                                <div class="lp-meta">By ${escapeHtml(lp.username)}, ${timeAgoJs(lp.created_at)}</div>
                            </div>
                        ` : `<span class="lp-none">No posts here yet</span>`}
                    </div>
                </div>`;
            }).join('')}
        </div>`;
    } catch(e) {
        container.innerHTML = '<div style="padding:30px;text-align:center;color:#aa3333">Failed to load forum.</div>';
    }
}

// ── Thread list inside a category ─────────────────────────────
async function loadCategoryView(categoryId, categoryName) {
    currentCategoryId = categoryId;
    const container = document.getElementById('forum-categories');
    container.innerHTML = `
        <div class="forum-back-btn" onclick="loadForumCategories()">← Back to Forum</div>
        <div class="forum-group">
            <div class="forum-group-header">
                <h2>💬 ${escapeHtml(categoryName)}</h2>
                ${currentUser ? `<span class="forum-new-thread-btn" onclick="showNewThreadForm(${categoryId})">+ New Thread</span>` : ''}
            </div>
            <div id="thread-list-inner"><div style="padding:20px;text-align:center;color:#555">Loading...</div></div>
        </div>`;

    try {
        const data = await forumPost({ action: 'get_threads', category_id: categoryId });
        const inner = document.getElementById('thread-list-inner');
        if (!data.success || !data.threads.length) {
            inner.innerHTML = '<div style="padding:24px;text-align:center;color:#555">No threads yet. Be the first to post!</div>';
            return;
        }
        inner.innerHTML = '<div class="forum-thread-list">' + data.threads.map(t => `
            <div class="forum-thread-row" onclick="showThread(${t.id})">
                <div class="th-icon">${t.is_pinned ? '📌' : (t.is_locked ? '🔒' : '💬')}</div>
                <div>
                    <div class="th-title">${escapeHtml(t.title)}</div>
                    <div class="th-by">By ${escapeHtml(t.username)} · ${timeAgoJs(t.created_at)}</div>
                </div>
                <div class="th-stat"><strong>${t.post_count ?? 0}</strong>replies</div>
                <div class="th-stat"><strong>${t.views ?? 0}</strong>views</div>
                <div class="th-last">
                    ${t.last_post_user ? `
                        <span class="th-last-title">Last by ${escapeHtml(t.last_post_user)}</span>
                        <span>${timeAgoJs(t.last_post_at)}</span>
                    ` : '<span style="color:#444">—</span>'}
                </div>
            </div>
        `).join('') + '</div>';
    } catch(e) {}
}

// ── Thread view with posts ─────────────────────────────────────
async function showThread(threadId) {
    currentThreadId = threadId;
    // Switch to forum-thread page
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const tp = document.getElementById('page-forum-thread');
    if (tp) tp.classList.add('active');
    window.scrollTo(0,0);

    document.getElementById('forum-thread-title').innerHTML = '<span style="color:#555">Loading...</span>';
    document.getElementById('forum-posts').innerHTML = '';

    try {
        const data = await forumPost({ action: 'get_thread', thread_id: threadId });
        if (!data.success) { showModal('Error', data.error); return; }
        currentThreadData = data.thread;

        // Title bar
        document.getElementById('forum-thread-title').innerHTML = `
            <div class="forum-back-btn" onclick="backToCategory()" style="margin-bottom:10px">← Back</div>
            ${data.thread.is_pinned ? '📌 ' : ''}${escapeHtml(data.thread.title)}
            <div style="font-size:11px;color:#555;margin-top:4px;font-weight:normal">
                Started by <strong style="color:#888">${escapeHtml(data.thread.username)}</strong> · ${timeAgoJs(data.thread.created_at)}
                ${data.thread.is_locked ? ' · <span style="color:#aa6600">🔒 Locked</span>' : ''}
            </div>
            ${isAdmin ? `
            <div class="forum-thread-admin-bar" style="margin-top:10px">
                <span>Admin:</span>
                <button class="admin-thread-btn" onclick="adminTogglePin(${threadId})">${data.thread.is_pinned ? 'Unpin' : '📌 Pin'}</button>
                <button class="admin-thread-btn" onclick="adminToggleLock(${threadId})">${data.thread.is_locked ? 'Unlock' : '🔒 Lock'}</button>
                <button class="admin-thread-btn danger" onclick="adminDeleteThread(${threadId})">🗑 Delete Thread</button>
            </div>` : ''}`;

        // Posts
        renderPosts(data.posts, data.thread.is_locked);

    } catch(e) { showModal('Error', 'Failed to load thread'); }
}

function renderPosts(posts, isLocked) {
    const box = document.getElementById('forum-posts');
    if (!posts.length) { box.innerHTML = '<div style="color:#555;padding:20px;text-align:center">No replies yet.</div>'; return; }

    box.innerHTML = posts.map(p => {
        let roleLabel = '';
        let avatarClass = '';
        if (p.is_super_admin) { roleLabel = '<span style="color:#ff4444;font-size:10px">⭐ Super Admin</span>'; avatarClass = 'superadmin'; }
        else if (p.is_admin)  { roleLabel = '<span style="color:#cc0000;font-size:10px">👑 Admin</span>'; }
        else if (p.is_vip)    { roleLabel = '<span style="color:#ffcc00;font-size:10px">⭐ VIP</span>'; avatarClass = 'vip'; }

        return `
        <div class="forum-post" id="fpost-${p.id}">
            <div class="forum-post-header">
                <div class="forum-post-userinfo">
                    ${makeAvatar(p.username, avatarClass)}
                    <div>
                        <div class="forum-post-author">${escapeHtml(p.username)} ${roleLabel}</div>
                        <div class="forum-post-postcount">Posts: ${p.user_post_count ?? 0}</div>
                    </div>
                </div>
                <div class="forum-post-time">${timeAgoJs(p.created_at)}</div>
            </div>
            <div class="forum-post-content">${escapeHtml(p.content).replace(/\n/g,'<br>')}</div>
            <div class="forum-post-footer">
                <button class="like-btn ${p.user_liked ? 'liked' : ''}" onclick="likePost(${p.id}, this)">
                    ❤️ ${p.like_count ?? 0}
                </button>
                ${isAdmin ? `
                <div class="admin-post-controls">
                    <button class="admin-post-btn del" onclick="adminDeletePost(${p.id})">🗑 Delete</button>
                </div>` : ''}
            </div>
        </div>`;
    }).join('');

    // Reply box
    const replyBox = document.getElementById('forum-reply-form');
    if (replyBox) {
        replyBox.style.display = (!currentUser || isLocked) ? 'none' : 'block';
        if (isLocked) {
            replyBox.insertAdjacentHTML('afterend', '<div style="padding:12px;color:#aa6600;font-size:12px;text-align:center">🔒 This thread is locked.</div>');
        }
    }
}

function backToCategory() {
    if (currentCategoryId) {
        showPage('forum');
        loadCategoryView(currentCategoryId, '');
    } else {
        showPage('forum');
        loadForumCategories();
    }
}

// ── Reply ─────────────────────────────────────────────────────
async function submitForumReply() {
    if (!currentUser) { showModal('Error', 'Please login to reply'); return; }
    const content = document.getElementById('forum-reply-content').value.trim();
    if (content.length < 5) { showModal('Error', 'Reply must be at least 5 characters'); return; }
    try {
        const data = await forumPost({ action: 'add_post', thread_id: currentThreadId, content });
        if (data.success) {
            document.getElementById('forum-reply-content').value = '';
            showThread(currentThreadId);
        } else { showModal('Error', data.error); }
    } catch(e) { showModal('Error', 'Failed to post reply'); }
}

// ── Create thread ─────────────────────────────────────────────
async function createNewThread() {
    if (!currentUser) { showModal('Error', 'Please login to create a thread'); return; }
    const category_id = document.getElementById('newthread_category').value;
    const title   = document.getElementById('newthread_title').value.trim();
    const content = document.getElementById('newthread_content').value.trim();
    if (title.length < 5)   { showModal('Error', 'Title must be at least 5 characters'); return; }
    if (content.length < 10){ showModal('Error', 'Content must be at least 10 characters'); return; }
    try {
        const data = await forumPost({ action: 'create_thread', category_id, title, content });
        if (data.success) {
            showModal('Posted!', 'Thread created successfully!');
            showPage('forum');
            loadForumCategories();
        } else { showModal('Error', data.error); }
    } catch(e) { showModal('Error', 'Failed to create thread'); }
}

// ── Like ──────────────────────────────────────────────────────
async function likePost(postId, btn) {
    if (!currentUser) { showModal('Error', 'Please login to like'); return; }
    try {
        const data = await forumPost({ action: 'like_post', post_id: postId });
        if (data.success) {
            btn.innerHTML = `❤️ ${data.count}`;
            btn.classList.toggle('liked', data.action === 'liked');
        }
    } catch(e) {}
}

// ── New thread form ───────────────────────────────────────────
async function showNewThreadForm(categoryId) {
    if (!currentUser) { showModal('Error', 'Please login to create a thread'); return; }
    try {
        const data = await forumPost({ action: 'get_categories' });
        const select = document.getElementById('newthread_category');
        if (data.success && data.categories) {
            select.innerHTML = data.categories
                .filter(c => !c.is_locked && (!c.is_admin_only || isAdmin))
                .map(c => `<option value="${c.id}" ${c.id == categoryId ? 'selected' : ''}>${escapeHtml(c.name)}</option>`)
                .join('');
        }
    } catch(e) {}
    document.getElementById('newthread_title').value   = '';
    document.getElementById('newthread_content').value = '';
    showPage('new-thread');
}

// ── Ban appeal ────────────────────────────────────────────────
async function submitBanAppeal() {
    if (!currentUser) { showModal('Error', 'Please login to submit an appeal'); return; }
    const ban_id   = document.getElementById('appeal_ban_id')?.value || 0;
    const reason   = document.getElementById('appeal_reason')?.value.trim();
    const evidence = document.getElementById('appeal_evidence')?.value.trim();
    if (!reason || reason.length < 10) { showModal('Error', 'Please explain your situation (min 10 characters)'); return; }
    try {
        const data = await forumPost({ action: 'submit_ban_appeal', ban_id, reason, evidence });
        if (data.success) {
            showModal('Appeal Submitted', 'An admin will review it within 48 hours.');
            ['appeal_reason','appeal_evidence','appeal_ban_id'].forEach(id => { const el=document.getElementById(id); if(el)el.value=''; });
        } else { showModal('Error', data.error); }
    } catch(e) { showModal('Error', 'Failed to submit appeal'); }
}

// ── Staff application ─────────────────────────────────────────
async function submitStaffApplication() {
    if (!currentUser) { showModal('Error', 'Please login to apply'); return; }
    const position    = document.getElementById('apply_position').value;
    const experience  = document.getElementById('apply_experience').value.trim();
    const reason      = document.getElementById('apply_reason').value.trim();
    const hours_weekly= document.getElementById('apply_hours').value;
    if (!experience || !reason || hours_weekly < 5) { showModal('Error', 'Please fill all fields correctly'); return; }
    try {
        const data = await forumPost({ action: 'submit_staff_app', position, experience, reason, hours_weekly });
        if (data.success) {
            showModal('Application Submitted!', 'An admin will review your application within 48 hours.');
            ['apply_experience','apply_reason','apply_hours'].forEach(id => { const el=document.getElementById(id); if(el)el.value=''; });
        } else { showModal('Error', data.error); }
    } catch(e) { showModal('Error', 'Failed to submit application'); }
}

// ── Report player (free text) ─────────────────────────────────
async function submitPlayerReport() {
    if (!currentUser) { showModal('Error', 'Please login to report'); return; }
    const reported_player = document.getElementById('report_username').value.trim();
    const reason          = document.getElementById('report_reason_text').value.trim();
    const evidence        = document.getElementById('report_evidence').value.trim();
    if (!reported_player) { showModal('Error', 'Please enter the player name'); return; }
    if (!reason || reason.length < 10) { showModal('Error', 'Please describe what happened (min 10 chars)'); return; }
    try {
        const data = await forumPost({ action: 'report_player', reported_player, reason, evidence });
        if (data.success) {
            showModal('Report Submitted', 'Thanks! Our staff will investigate.');
            ['report_username','report_reason_text','report_evidence'].forEach(id => { const el=document.getElementById(id); if(el)el.value=''; });
        } else { showModal('Error', data.error); }
    } catch(e) { showModal('Error', 'Failed to submit report'); }
}

// ── Admin actions ─────────────────────────────────────────────
async function adminDeletePost(postId) {
    if (!confirm('Delete this post?')) return;
    try {
        const data = await forumPost({ action: 'delete_post', post_id: postId });
        if (data.success) {
            const el = document.getElementById(`fpost-${postId}`);
            if (el) el.remove();
        } else { showModal('Error', data.error); }
    } catch(e) {}
}

async function adminDeleteThread(threadId) {
    if (!confirm('Delete entire thread? This cannot be undone.')) return;
    try {
        const data = await forumPost({ action: 'delete_thread', thread_id: threadId });
        if (data.success) { showPage('forum'); loadForumCategories(); }
        else { showModal('Error', data.error); }
    } catch(e) {}
}

async function adminTogglePin(threadId) {
    try {
        const data = await forumPost({ action: 'toggle_pin', thread_id: threadId });
        if (data.success) showThread(threadId);
    } catch(e) {}
}

async function adminToggleLock(threadId) {
    try {
        const data = await forumPost({ action: 'toggle_lock', thread_id: threadId });
        if (data.success) showThread(threadId);
    } catch(e) {}
}

// ── Forum AJAX helper ─────────────────────────────────────────
async function forumPost(data) {
    const body = new URLSearchParams(data).toString();
    const res = await fetch('ajax/forum_handler.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
        body
    });
    return res.json();
}
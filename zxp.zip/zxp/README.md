# ZXP.lt Gaming Portal — Setup Guide

## Folder Structure
```
zxp/
├── index.php              ← Main page (put in C:\xampp\htdocs\zxp\)
├── install.sql            ← Run this in phpMyAdmin FIRST
├── .htaccess              ← Apache security rules
├── config/
│   ├── database.php       ← DB connection + all functions
│   └── functions.php      ← Helper functions
├── ajax/
│   ├── handler.php        ← Main AJAX handler (login, register, payment...)
│   ├── forum_handler.php  ← Forum AJAX handler
│   ├── paypal_ipn.php     ← PayPal payment confirmation (auto-called by PayPal)
│   └── stripe_webhook.php ← Stripe payment confirmation (auto-called by Stripe)
├── assets/
│   ├── css/style.css
│   └── js/script.js
├── vendor/                ← Created by Composer (Stripe SDK)
└── logs/                  ← Auto-created, stores payment logs
```

---

## Step 1 — Stripe (already done ✅)
You ran: `composer require stripe/stripe-php` in `C:\xampp\htdocs\zxp\`
The `vendor/` folder was created. Keep it there.

---

## Step 2 — Database Setup
1. Open **phpMyAdmin** → http://localhost/phpmyadmin
2. Click **Import** tab
3. Choose `install.sql` and click **Go**
4. Database `zxp` will be created with all tables + sample data

---

## Step 3 — Configure Settings
After running install.sql, go to phpMyAdmin → zxp → settings table and update:

| setting_key          | Value                        |
|----------------------|------------------------------|
| site_url             | https://zxp.lt (your domain) |
| admin_email          | your@email.com               |
| paypal_email         | your PayPal business email   |
| stripe_secret_key    | sk_live_xxxxx (from Stripe)  |
| stripe_public_key    | pk_live_xxxxx (from Stripe)  |
| stripe_webhook_secret| whsec_xxxxx (from Stripe)    |
| crypto_wallet_btc    | Your BTC address             |
| crypto_wallet_eth    | Your ETH address             |
| crypto_wallet_usdt   | Your USDT TRC20 address      |
| discord_link         | https://discord.gg/yourlink  |
| gunxp_ip             | your.server.ip:port          |
| zp_ip                | your.server.ip:port          |

---

## Step 4 — Test Locally
Open: http://localhost/zxp/
Login with: **Admin** / **admin123**

---

## Step 5 — Payment Setup (Live)

### PayPal
1. Log into PayPal Business account
2. Set IPN URL to: `https://yourdomain.com/ajax/paypal_ipn.php`
   (PayPal Dashboard → Account Settings → Notifications → IPN)

### Stripe
1. Log into stripe.com → Developers → Webhooks
2. Add endpoint: `https://yourdomain.com/ajax/stripe_webhook.php`
3. Select event: `checkout.session.completed`
4. Copy the **Signing Secret** → paste into settings table as `stripe_webhook_secret`

### Stripe Test Mode
For local testing use `sk_test_xxx` and `pk_test_xxx` keys from Stripe Dashboard.

---

## Default Login
- Username: `Admin`  
- Password: `admin123`  
⚠️ **Change this immediately after setup!**

---

## Common Issues

**"Database Error"** → Make sure XAMPP MySQL is running and you ran install.sql

**Forum not loading** → Check browser console for errors. Make sure `ajax/forum_handler.php` exists.

**Stripe error "autoload not found"** → Run `composer require stripe/stripe-php` inside the `zxp/` folder

**PayPal not activating orders** → IPN URL must be live (not localhost). Use ngrok for testing.

<?php
// ajax/forum_handler.php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$action = trim($_POST['action'] ?? '');
$response = ['success' => false, 'error' => 'Unknown action'];

switch ($action) {
    case 'get_categories':
        $categories = getForumCategories($pdo);
        foreach ($categories as &$cat) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_threads WHERE category_id = ?");
            $stmt->execute([$cat['id']]);
            $cat['thread_count'] = (int)$stmt->fetchColumn();
        }
        $response = ['success' => true, 'categories' => $categories];
        break;
        
    case 'get_threads':
        $category_id = (int)($_POST['category_id'] ?? 0);
        $page = (int)($_POST['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $threads = getThreadsByCategory($pdo, $category_id, $limit, $offset);
        $response = ['success' => true, 'threads' => $threads];
        break;
        
    case 'get_thread':
        $thread_id = (int)($_POST['thread_id'] ?? 0);
        $page = (int)($_POST['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Get thread info
        $stmt = $pdo->prepare("SELECT t.*, u.username FROM forum_threads t JOIN users u ON u.id = t.user_id WHERE t.id = ?");
        $stmt->execute([$thread_id]);
        $thread = $stmt->fetch();
        
        if (!$thread) {
            $response = ['success' => false, 'error' => 'Thread not found'];
            break;
        }
        
        // Increment views
        $pdo->prepare("UPDATE forum_threads SET views = views + 1 WHERE id = ?")->execute([$thread_id]);
        
        $posts = getThreadPosts($pdo, $thread_id, $limit, $offset);
        $response = ['success' => true, 'thread' => $thread, 'posts' => $posts];
        break;
        
    case 'create_thread':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $category_id = (int)($_POST['category_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        
        if (strlen($title) < 5) {
            $response = ['success' => false, 'error' => 'Title must be at least 5 characters'];
            break;
        }
        if (strlen($content) < 10) {
            $response = ['success' => false, 'error' => 'Content must be at least 10 characters'];
            break;
        }
        
        $thread_id = createThread($pdo, $category_id, $_SESSION['user_id'], $title, $content);
        if ($thread_id) {
            $response = ['success' => true, 'thread_id' => $thread_id];
        } else {
            $response = ['success' => false, 'error' => 'Failed to create thread'];
        }
        break;
        
    case 'add_post':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $thread_id = (int)($_POST['thread_id'] ?? 0);
        $content = trim($_POST['content'] ?? '');
        
        if (strlen($content) < 5) {
            $response = ['success' => false, 'error' => 'Content must be at least 5 characters'];
            break;
        }
        
        if (addPost($pdo, $thread_id, $_SESSION['user_id'], $content)) {
            $response = ['success' => true];
        } else {
            $response = ['success' => false, 'error' => 'Failed to add post'];
        }
        break;
        
    case 'like_post':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $post_id = (int)($_POST['post_id'] ?? 0);
        $result = likePost($pdo, $post_id, $_SESSION['user_id']);
        $response = ['success' => true, 'action' => $result['action'], 'count' => $result['count']];
        break;
        
    case 'submit_staff_app':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $position = trim($_POST['position'] ?? '');
        $experience = trim($_POST['experience'] ?? '');
        $reason = trim($_POST['reason'] ?? '');
        $hours_weekly = (int)($_POST['hours_weekly'] ?? 0);
        
        if (!$position || !$experience || !$reason || $hours_weekly < 5) {
            $response = ['success' => false, 'error' => 'Please fill all fields correctly'];
            break;
        }
        
        if (submitStaffApplication($pdo, $_SESSION['user_id'], $position, $experience, $reason, $hours_weekly)) {
            $response = ['success' => true];
        } else {
            $response = ['success' => false, 'error' => 'Failed to submit application'];
        }
        break;
        
    case 'submit_ban_appeal':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $ban_id = (int)($_POST['ban_id'] ?? 0);
        $reason = trim($_POST['reason'] ?? '');
        $evidence = trim($_POST['evidence'] ?? '');
        
        if (!$reason) {
            $response = ['success' => false, 'error' => 'Please provide a reason'];
            break;
        }
        
        if (submitBanAppeal($pdo, $_SESSION['user_id'], $ban_id, $reason, $evidence)) {
            $response = ['success' => true];
        } else {
            $response = ['success' => false, 'error' => 'Failed to submit appeal'];
        }
        break;
        
    case 'report_player':
        if (!isLoggedIn()) {
            $response = ['success' => false, 'error' => 'Login required'];
            break;
        }
        
        $reported_player = trim($_POST['reported_player'] ?? '');
        $reason = trim($_POST['reason'] ?? '');
        $evidence = trim($_POST['evidence'] ?? '');
        
        if (!$reported_player || !$reason) {
            $response = ['success' => false, 'error' => 'Please fill all required fields'];
            break;
        }
        
        if (submitPlayerReport($pdo, $_SESSION['user_id'], $reported_player, $reason, $evidence)) {
            $response = ['success' => true];
        } else {
            $response = ['success' => false, 'error' => 'Failed to submit report'];
        }
        break;
        
    case 'get_server_status':
        $gunxp = getServerStatus($pdo, 'gunxp');
        $zp = getServerStatus($pdo, 'zp');
        $response = ['success' => true, 'gunxp' => $gunxp, 'zp' => $zp];
        break;

    // ── ADMIN: Delete post ─────────────────────────────────────
    case 'delete_post':
        if (!isAdmin()) { $response = ['success' => false, 'error' => 'Admin only']; break; }
        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) { $response = ['success' => false, 'error' => 'Invalid post']; break; }
        $pdo->prepare("DELETE FROM forum_posts WHERE id = ?")->execute([$post_id]);
        $response = ['success' => true];
        break;

    // ── ADMIN: Delete thread ───────────────────────────────────
    case 'delete_thread':
        if (!isAdmin()) { $response = ['success' => false, 'error' => 'Admin only']; break; }
        $thread_id = (int)($_POST['thread_id'] ?? 0);
        if (!$thread_id) { $response = ['success' => false, 'error' => 'Invalid thread']; break; }
        $pdo->prepare("DELETE FROM forum_threads WHERE id = ?")->execute([$thread_id]);
        $response = ['success' => true];
        break;

    // ── ADMIN: Pin/Unpin thread ────────────────────────────────
    case 'toggle_pin':
        if (!isAdmin()) { $response = ['success' => false, 'error' => 'Admin only']; break; }
        $thread_id = (int)($_POST['thread_id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE forum_threads SET is_pinned = NOT is_pinned WHERE id = ?");
        $stmt->execute([$thread_id]);
        $state = $pdo->prepare("SELECT is_pinned FROM forum_threads WHERE id = ?");
        $state->execute([$thread_id]);
        $response = ['success' => true, 'pinned' => (bool)$state->fetchColumn()];
        break;

    // ── ADMIN: Lock/Unlock thread ──────────────────────────────
    case 'toggle_lock':
        if (!isAdmin()) { $response = ['success' => false, 'error' => 'Admin only']; break; }
        $thread_id = (int)($_POST['thread_id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE forum_threads SET is_locked = NOT is_locked WHERE id = ?");
        $stmt->execute([$thread_id]);
        $state = $pdo->prepare("SELECT is_locked FROM forum_threads WHERE id = ?");
        $state->execute([$thread_id]);
        $response = ['success' => true, 'locked' => (bool)$state->fetchColumn()];
        break;
}

echo json_encode($response);
?>
<?php
// ajax/paypal_ipn.php — PayPal Instant Payment Notification Handler
// PayPal sends POST here after every payment. We verify + mark order paid.
require_once '../config/database.php';

// Step 1: Read raw POST data from PayPal
$raw_post = file_get_contents('php://input');
if (empty($raw_post)) exit;

// Step 2: Send back to PayPal for verification
$verify_url = 'https://ipnpb.paypal.com/cgi-bin/webscr'; // live
// $verify_url = 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr'; // sandbox

$ch = curl_init($verify_url);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'cmd=_notify-validate&' . $raw_post);
curl_setopt($ch, CURLOPT_SSLVERSION, 6); // TLS 1.2
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_FORBID_REUSE, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Connection: Close']);
$verify_response = curl_exec($ch);
curl_close($ch);

if ($verify_response !== 'VERIFIED') {
    // Log invalid IPN attempts
    file_put_contents(__DIR__ . '/../logs/ipn_invalid.log',
        date('Y-m-d H:i:s') . " - INVALID IPN\n", FILE_APPEND);
    exit;
}

// Step 3: Parse POST data
parse_str($raw_post, $ipn);

$payment_status = $ipn['payment_status'] ?? '';
$receiver_email = strtolower($ipn['receiver_email'] ?? '');
$custom         = $ipn['custom'] ?? ''; // "username|package|order_id"
$mc_gross       = (float)($ipn['mc_gross'] ?? 0);
$mc_currency    = $ipn['mc_currency'] ?? '';

$admin_email = strtolower(getSetting($pdo, 'admin_email') ?? 'admin@zxp.lt');
$paypal_email = strtolower(getSetting($pdo, 'paypal_email') ?? '');

// Step 4: Validate
if ($payment_status !== 'Completed') exit;
if ($receiver_email !== $paypal_email) exit;
if ($mc_currency !== 'EUR') exit;

// Parse custom field
$parts    = explode('|', $custom);
$username = $parts[0] ?? '';
$package  = $parts[1] ?? '';
$order_id = (int)($parts[2] ?? 0);

if (!$order_id) exit;

$prices = ['vip_1m'=>5, 'vip_3m'=>12, 'admin_1m'=>10, 'admin_3m'=>25];
$expected = $prices[$package] ?? 0;
if ($mc_gross < $expected) exit; // underpaid

// Step 5: Mark order as paid
$stmt = $pdo->prepare("UPDATE orders SET status='paid', paid_at=NOW() WHERE id=? AND status='pending'");
$stmt->execute([$order_id]);

// Step 6: Log for admin review
$log = date('Y-m-d H:i:s') . " | PAID | Order #$order_id | $username | $package | €$mc_gross\n";
@mkdir(__DIR__ . '/../logs', 0755, true);
file_put_contents(__DIR__ . '/../logs/paypal_paid.log', $log, FILE_APPEND);

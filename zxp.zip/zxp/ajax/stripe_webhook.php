<?php
// ajax/stripe_webhook.php — Stripe Webhook Handler
// Set this URL in Stripe Dashboard → Webhooks → checkout.session.completed
require_once '../config/database.php';
require_once '../vendor/autoload.php';

$stripe_secret    = getSetting($pdo, 'stripe_secret_key') ?? '';
$webhook_secret   = getSetting($pdo, 'stripe_webhook_secret') ?? ''; // from Stripe Dashboard

$payload = file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $webhook_secret);
} catch (\UnexpectedValueException $e) {
    http_response_code(400);
    exit;
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    http_response_code(400);
    exit;
}

if ($event->type === 'checkout.session.completed') {
    $session  = $event->data->object;
    $metadata = $session->metadata;
    $order_id = (int)($metadata->order_id ?? 0);

    if ($order_id) {
        $stmt = $pdo->prepare("UPDATE orders SET status='paid', paid_at=NOW() WHERE id=? AND status='pending'");
        $stmt->execute([$order_id]);

        $log = date('Y-m-d H:i:s') . " | PAID | Order #$order_id | {$metadata->username} | {$metadata->package}\n";
        @mkdir(__DIR__ . '/../logs', 0755, true);
        file_put_contents(__DIR__ . '/../logs/stripe_paid.log', $log, FILE_APPEND);
    }
}

http_response_code(200);
echo json_encode(['received' => true]);

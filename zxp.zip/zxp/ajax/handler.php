<?php
// ajax/handler.php
require_once '../config/database.php';

header('Content-Type: application/json');

// Only allow POST + AJAX
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

$action   = trim($_POST['action'] ?? '');
$response = ['success' => false, 'error' => 'Unknown action'];

switch ($action) {

    // ── LOGIN ─────────────────────────────────────────────────
    case 'login':
        $uname = trim($_POST['username'] ?? '');
        $pass  = $_POST['password'] ?? '';

        if (!$uname || !$pass) {
            $response = ['success' => false, 'error' => 'Enter username and password'];
            break;
        }

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_banned = 0");
        $stmt->execute([$uname]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['user_id']       = $user['id'];
            $_SESSION['username']      = $user['username'];
            $_SESSION['is_admin']      = $user['is_admin'];
            $_SESSION['is_super_admin']= $user['is_super_admin'];
            $_SESSION['is_vip']        = $user['is_vip'];

            $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")
                ->execute([$user['id']]);

            $unread = getUnreadCount($pdo, $user['id']);

            $response = [
                'success'        => true,
                'username'       => $user['username'],
                'level'          => $user['level'],
                'xp'             => $user['xp'],
                'is_admin'       => (bool)$user['is_admin'],
                'is_super_admin' => (bool)$user['is_super_admin'],
                'is_vip'         => (bool)$user['is_vip'],
                'unread_count'   => $unread,
            ];
        } else {
            $banned = $pdo->prepare("SELECT is_banned, ban_reason FROM users WHERE username = ?");
            $banned->execute([$uname]);
            $b = $banned->fetch();
            if ($b && $b['is_banned']) {
                $response = ['success' => false, 'error' => 'Account banned: ' . $b['ban_reason']];
            } else {
                $response = ['success' => false, 'error' => 'Invalid username or password'];
            }
        }
        break;

    // ── REGISTER ──────────────────────────────────────────────
    case 'register':
        $uname = trim($_POST['username'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $email = trim($_POST['email'] ?? '');

        if (strlen($uname) < 3) { $response = ['success'=>false,'error'=>'Username must be 3+ characters']; break; }
        if (strlen($pass)  < 4) { $response = ['success'=>false,'error'=>'Password must be 4+ characters']; break; }
        if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response = ['success'=>false,'error'=>'Invalid email address']; break;
        }
        if (!preg_match('/^[a-zA-Z0-9_\-\. ]+$/', $uname)) {
            $response = ['success'=>false,'error'=>'Username has invalid characters']; break;
        }

        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $check->execute([$uname]);
        if ($check->fetchColumn() > 0) {
            $response = ['success'=>false,'error'=>'Username already taken']; break;
        }

        $hashed = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username,password,email,created_at) VALUES (?,?,?,NOW())");

        if ($stmt->execute([$uname, $hashed, $email])) {
            $response = ['success' => true];
        } else {
            $response = ['success'=>false,'error'=>'Registration failed. Try again.'];
        }
        break;

    // ── LOGOUT ────────────────────────────────────────────────
    case 'logout':
        session_destroy();
        $response = ['success' => true];
        break;

    // ── SHOUT ─────────────────────────────────────────────────
    case 'shout':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }
        $msg = trim($_POST['message'] ?? '');
        if (!$msg || strlen($msg) > 200) {
            $response = ['success'=>false,'error'=>'Message must be 1-200 characters']; break;
        }
        if (addShout($pdo, $_SESSION['user_id'], $msg)) {
            $response = ['success' => true];
        } else {
            $response = ['success'=>false,'error'=>'Failed to post. Try again.'];
        }
        break;

    // ── GET SHOUTS ────────────────────────────────────────────
    case 'get_shouts':
        $shouts = getShouts($pdo, 10);
        $response = ['success' => true, 'shouts' => $shouts];
        break;

    // ── CONTACT ───────────────────────────────────────────────
    case 'contact':
        $nickname = trim($_POST['nickname'] ?? '');
        $email    = trim($_POST['email']    ?? '');
        $subject  = trim($_POST['subject']  ?? '');
        $message  = trim($_POST['message']  ?? '');

        if (!$nickname || !$email || !$message) {
            $response = ['success'=>false,'error'=>'Fill all required fields']; break;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response = ['success'=>false,'error'=>'Invalid email address']; break;
        }
        if (strlen($message) < 10) {
            $response = ['success'=>false,'error'=>'Message too short (min 10 chars)']; break;
        }

        $stmt = $pdo->prepare(
            "INSERT INTO contact_messages (nickname,email,subject,message,created_at)
             VALUES (?,?,?,?,NOW())"
        );
        if ($stmt->execute([
            htmlspecialchars($nickname, ENT_QUOTES),
            $email,
            htmlspecialchars($subject, ENT_QUOTES),
            htmlspecialchars($message, ENT_QUOTES)
        ])) {
            $response = ['success' => true];
        } else {
            $response = ['success'=>false,'error'=>'Failed to send. Try again.'];
        }
        break;

    // ── PAYMENT / ORDER VIP (Crypto + Discord only) ───────────
    case 'order_vip':
        $package  = trim($_POST['package']  ?? '');
        $username = trim($_POST['username'] ?? '');
        $method   = trim($_POST['method']   ?? '');

        if (!$package || !$username || !$method) {
            $response = ['success'=>false,'error'=>'Fill all fields']; break;
        }

        $prices = ['vip_1m'=>5, 'vip_3m'=>12, 'admin_1m'=>10, 'admin_3m'=>25];
        if (!array_key_exists($package, $prices)) {
            $response = ['success'=>false,'error'=>'Invalid package']; break;
        }

        $amount = $prices[$package];

        $stmt = $pdo->prepare(
            "INSERT INTO orders (username, package, amount, payment_method, status, created_at)
             VALUES (?,?,?,?,'pending',NOW())"
        );
        if ($stmt->execute([$username, $package, $amount, $method])) {
            $order_id    = $pdo->lastInsertId();
            $admin_email = getSetting($pdo, 'admin_email') ?? 'admin@zxp.lt';
            $discord     = getSetting($pdo, 'discord_link') ?? 'https://discord.gg/BSp88gJmpx';
            $btc_wallet  = getSetting($pdo, 'crypto_wallet_btc')  ?? 'YOUR_BTC_WALLET';
            $eth_wallet  = getSetting($pdo, 'crypto_wallet_eth')  ?? 'YOUR_ETH_WALLET';
            $usdt_wallet = getSetting($pdo, 'crypto_wallet_usdt') ?? 'YOUR_USDT_TRC20_WALLET';

            $note = "Order #$order_id - $username - $package";

            if ($method === 'crypto_btc') {
                $response = [
                    'success'  => true,
                    'method'   => 'crypto_btc',
                    'amount'   => $amount,
                    'order_id' => $order_id,
                    'wallet'   => $btc_wallet,
                    'note'     => $note,
                    'discord'  => $discord,
                ];
            } elseif ($method === 'crypto_eth') {
                $response = [
                    'success'  => true,
                    'method'   => 'crypto_eth',
                    'amount'   => $amount,
                    'order_id' => $order_id,
                    'wallet'   => $eth_wallet,
                    'note'     => $note,
                    'discord'  => $discord,
                ];
            } elseif ($method === 'crypto_usdt') {
                $response = [
                    'success'  => true,
                    'method'   => 'crypto_usdt',
                    'amount'   => $amount,
                    'order_id' => $order_id,
                    'wallet'   => $usdt_wallet,
                    'note'     => $note,
                    'discord'  => $discord,
                ];
            } elseif ($method === 'discord') {
                $response = [
                    'success'  => true,
                    'method'   => 'discord',
                    'amount'   => $amount,
                    'order_id' => $order_id,
                    'discord'  => $discord,
                    'note'     => $note,
                ];
            } elseif ($method === 'paypal') {
                // PayPal Standard hosted button — redirect user to PayPal checkout
                $paypal_email  = getSetting($pdo, 'paypal_email') ?? 'your@paypal.com';
                $return_url    = getSetting($pdo, 'site_url') ?? 'https://zxp.lt';
                $paypal_url    = 'https://www.paypal.com/cgi-bin/webscr?' . http_build_query([
                    'cmd'           => '_xclick',
                    'business'      => $paypal_email,
                    'item_name'     => "ZXP.lt - $package (Order #$order_id)",
                    'item_number'   => $order_id,
                    'amount'        => $amount,
                    'currency_code' => 'EUR',
                    'return'        => $return_url . '?payment=success&order=' . $order_id,
                    'cancel_return' => $return_url . '?payment=cancel',
                    'custom'        => "$username|$package|$order_id",
                    'notify_url'    => $return_url . '/ajax/paypal_ipn.php',
                ]);
                $response = [
                    'success'     => true,
                    'method'      => 'paypal',
                    'amount'      => $amount,
                    'order_id'    => $order_id,
                    'paypal_url'  => $paypal_url,
                    'discord'     => $discord,
                ];
            } elseif ($method === 'stripe') {
                // Stripe Checkout — requires stripe/stripe-php composer package
                // composer require stripe/stripe-php
                $stripe_secret = getSetting($pdo, 'stripe_secret_key') ?? '';
                if (!$stripe_secret || strpos($stripe_secret, 'sk_') !== 0) {
                    $response = ['success'=>false,'error'=>'Stripe not configured. Use crypto or Discord.'];
                    break;
                }
                try {
                    require_once __DIR__ . '/../vendor/autoload.php';
                    \Stripe\Stripe::setApiKey($stripe_secret);
                    $site_url = getSetting($pdo, 'site_url') ?? 'https://zxp.lt';
                    $session = \Stripe\Checkout\Session::create([
                        'payment_method_types' => ['card'],
                        'line_items' => [[
                            'price_data' => [
                                'currency'     => 'eur',
                                'unit_amount'  => $amount * 100, // cents
                                'product_data' => [
                                    'name' => "ZXP.lt — " . strtoupper(str_replace('_', ' ', $package)),
                                    'description' => "Order #$order_id for $username",
                                ],
                            ],
                            'quantity' => 1,
                        ]],
                        'mode'        => 'payment',
                        'success_url' => $site_url . '?payment=success&order=' . $order_id,
                        'cancel_url'  => $site_url . '?payment=cancel',
                        'metadata'    => ['order_id' => $order_id, 'username' => $username, 'package' => $package],
                    ]);
                    // Mark order with stripe session id
                    $pdo->prepare("UPDATE orders SET notes = ? WHERE id = ?")->execute([$session->id, $order_id]);
                    $response = [
                        'success'     => true,
                        'method'      => 'stripe',
                        'amount'      => $amount,
                        'order_id'    => $order_id,
                        'stripe_url'  => $session->url,
                    ];
                } catch (Exception $e) {
                    $response = ['success'=>false,'error'=>'Stripe error: ' . $e->getMessage()];
                }
            } else {
                $response = ['success'=>false,'error'=>'Invalid payment method'];
            }
        } else {
            $response = ['success'=>false,'error'=>'Order failed. Contact admin.'];
        }
        break;

    // ── GUEST COUNT ───────────────────────────────────────────
    case 'get_guest_count':
        if (!isset($_SESSION['guest_count'])) {
            $_SESSION['guest_count'] = rand(5, 15);
        }
        $_SESSION['guest_count'] += rand(-1, 1);
        $_SESSION['guest_count'] = max(2, min(20, $_SESSION['guest_count']));
        $response = ['success'=>true, 'count'=>$_SESSION['guest_count']];
        break;

    // ── SEND PRIVATE MESSAGE ──────────────────────────────────
    case 'send_pm':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }
        $receiver_id = (int)($_POST['receiver_id'] ?? 0);
        $msg = trim($_POST['message'] ?? '');

        if (!$receiver_id || !$msg) {
            $response = ['success'=>false,'error'=>'Invalid data']; break;
        }
        if (strlen($msg) > 500) {
            $response = ['success'=>false,'error'=>'Message too long (max 500 chars)']; break;
        }

        // Check receiver exists
        $chk = $pdo->prepare("SELECT id FROM users WHERE id = ? AND is_banned = 0");
        $chk->execute([$receiver_id]);
        if (!$chk->fetch()) {
            $response = ['success'=>false,'error'=>'User not found']; break;
        }

        $stmt = $pdo->prepare(
            "INSERT INTO private_messages (sender_id, receiver_id, message, created_at)
             VALUES (?, ?, ?, NOW())"
        );
        if ($stmt->execute([$_SESSION['user_id'], $receiver_id, htmlspecialchars($msg, ENT_QUOTES, 'UTF-8')])) {
            $response = ['success' => true];
        } else {
            $response = ['success'=>false,'error'=>'Failed to send message'];
        }
        break;

    // ── GET PRIVATE MESSAGES ──────────────────────────────────
    case 'get_pm':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }
        $with_user = (int)($_POST['with_user'] ?? 0);
        if (!$with_user) { $response = ['success'=>false,'error'=>'Invalid user']; break; }

        $messages = getPrivateMessages($pdo, $_SESSION['user_id'], $with_user, 50);

        // Mark as read
        $pdo->prepare(
            "UPDATE private_messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?"
        )->execute([$_SESSION['user_id'], $with_user]);

        $response = ['success' => true, 'messages' => $messages, 'my_id' => $_SESSION['user_id']];
        break;

    // ── GET USERS LIST (for chat) ─────────────────────────────
    case 'get_users_list':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }
        $users = getUsersList($pdo, $_SESSION['user_id']);
        $response = ['success' => true, 'users' => $users];
        break;

    // ── DELETE PRIVATE MESSAGE ────────────────────────────────
    case 'delete_pm':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }
        $msg_id = (int)($_POST['msg_id'] ?? 0);
        if (!$msg_id) { $response = ['success'=>false,'error'=>'Invalid message']; break; }
        // Only sender or receiver can delete
        $stmt = $pdo->prepare("DELETE FROM private_messages WHERE id = ? AND (sender_id = ? OR receiver_id = ?)");
        $stmt->execute([$msg_id, $_SESSION['user_id'], $_SESSION['user_id']]);
        $response = ['success' => true];
        break;

    // ── GET UNREAD COUNT ──────────────────────────────────────
    case 'get_unread':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Not logged in']; break; }
        $count = getUnreadCount($pdo, $_SESSION['user_id']);
        $response = ['success' => true, 'count' => $count];
        break;

    // ── UPDATE PROFILE (username/password change) ─────────────
    case 'update_profile':
        if (!isLoggedIn()) { $response = ['success'=>false,'error'=>'Login first']; break; }

        $new_username = trim($_POST['new_username'] ?? '');
        $new_password = $_POST['new_password'] ?? '';
        $current_pass = $_POST['current_password'] ?? '';

        // Verify current password
        $user = getUser($pdo, $_SESSION['user_id']);
        if (!$user || !password_verify($current_pass, $user['password'])) {
            $response = ['success'=>false,'error'=>'Current password is wrong']; break;
        }

        $updates = [];
        $params  = [];

        // Username change
        if ($new_username && $new_username !== $user['username']) {
            if (strlen($new_username) < 3) { $response = ['success'=>false,'error'=>'Username must be 3+ chars']; break; }
            if (!preg_match('/^[a-zA-Z0-9_\-\. ]+$/', $new_username)) {
                $response = ['success'=>false,'error'=>'Username has invalid characters']; break;
            }
            $chkU = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
            $chkU->execute([$new_username, $_SESSION['user_id']]);
            if ($chkU->fetchColumn() > 0) {
                $response = ['success'=>false,'error'=>'Username already taken']; break;
            }
            $updates[] = 'username = ?';
            $params[]  = $new_username;
        }

        // Password change
        if ($new_password) {
            if (strlen($new_password) < 4) { $response = ['success'=>false,'error'=>'New password must be 4+ chars']; break; }
            $updates[] = 'password = ?';
            $params[]  = password_hash($new_password, PASSWORD_DEFAULT);
        }

        if (empty($updates)) {
            $response = ['success'=>false,'error'=>'Nothing to update']; break;
        }

        $params[] = $_SESSION['user_id'];
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        $pdo->prepare($sql)->execute($params);

        // Update session
        if ($new_username && $new_username !== $user['username']) {
            $_SESSION['username'] = $new_username;
        }

        $response = ['success' => true, 'new_username' => $_SESSION['username']];
        break;

    // ── GOOGLE AUTH LINK (for password recovery) ─────────────
    case 'google_auth_link':
        $email = trim($_POST['email'] ?? '');
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response = ['success'=>false,'error'=>'Enter valid email']; break;
        }

        // Check if user exists with this email
        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            // Don't reveal if email exists - security
            $response = ['success'=>true,'message'=>'If this email is registered, a reset link concept will be shown.'];
            break;
        }

        // Generate token
        $token   = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $pdo->prepare(
            "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)"
        )->execute([$user['id'], $token, $expires]);

        // In a real setup you'd send email. Here we return the token for demo.
        $response = [
            'success'  => true,
            'message'  => 'Recovery initiated! Check your email or contact admin on Discord.',
            'discord'  => getSetting($pdo, 'discord_link') ?? 'https://discord.gg/BSp88gJmpx',
            // In production: send $token via email to the user
        ];
        break;

    // ── RESET PASSWORD WITH TOKEN ─────────────────────────────
    case 'reset_password':
        $token    = trim($_POST['token'] ?? '');
        $new_pass = $_POST['new_password'] ?? '';

        if (!$token || strlen($new_pass) < 4) {
            $response = ['success'=>false,'error'=>'Invalid token or password too short']; break;
        }

        $stmt = $pdo->prepare(
            "SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at > NOW()"
        );
        $stmt->execute([$token]);
        $reset = $stmt->fetch();

        if (!$reset) {
            $response = ['success'=>false,'error'=>'Invalid or expired token']; break;
        }

        // Update password
        $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed, $reset['user_id']]);
        $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = ?")->execute([$reset['id']]);

        $response = ['success'=>true, 'message'=>'Password updated! You can now login.'];
        break;

    // ── MAKE SUPER ADMIN (only super admins can do this) ──────
    case 'set_super_admin':
        if (!isSuperAdmin()) { $response = ['success'=>false,'error'=>'Access denied']; break; }
        $target_id = (int)($_POST['user_id'] ?? 0);
        $val       = (int)($_POST['value']   ?? 0);
        if (!$target_id) { $response = ['success'=>false,'error'=>'Invalid user']; break; }

        $pdo->prepare("UPDATE users SET is_super_admin = ?, is_admin = ? WHERE id = ?")
            ->execute([$val, $val ? 1 : 0, $target_id]);
        $response = ['success' => true];
        break;
}

echo json_encode($response);
